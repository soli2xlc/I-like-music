# goosemusic

YouTube-search music player with local playback and OS media controls, built with iced.

## Stack

- **Language**: Rust (edition 2021); **UI**: iced 0.14 (`iced::application(boot, update, view)`); **Audio**: rodio + symphonia; **pipeline**: yt-dlp (stream/download)
- **Media controls**: souvlaki (MPRIS/D-Bus on Linux, SMTC on Windows, Now Playing on macOS); **Config**: JsonStore + directories; **HTTP**: ureq 3 (json); **Dialogs**: rfd 0.15; **Logging**: tracing + tracing-subscriber
- **Lyrics**: pluggable provider trait (`lyrics.rs`), LRCLib default, Genius (keyless web API: lyrics from embedded `__PRELOADED_STATE__` with container-scrape fallback, per-line annotations and song blurb as notes, lazy `translation_songs` in a language picker row), plus named user-added per-track lyrics (plain or LRC-synced) as tabs after the providers, editable/deletable from the lyrics view; cache in `data/lyrics_cache.rs`; AI translate (`translate.rs`, OpenAI-compatible/Ollama, BYOK in Settings) opens the result in the custom-lyrics editor under the target language

## Prerequisites

- **yt-dlp** (stream/download, serves AAC-in-M4A which symphonia decodes)
- **Python 3** + **ytmusicapi** for search (falls back to yt-dlp); **D-Bus** session bus (Linux) for MPRIS; Windows/macOS use their native media controls (no extra deps)

## Build & Run

```sh
cargo build && cargo run
# rustfmt.toml uses unstable import options; plain `cargo fmt` silently ignores them
cargo +nightly fmt && cargo clippy && cargo test
```

## Version Control

**Do not commit unless explicitly asked.** Leave changes in the working tree and report what changed; the user decides when and how it lands. This covers `git commit` and anything that implicitly commits (`git merge`, `git rebase`, `git stash`, `git checkout` over local edits). Never `push`, amend, or rewrite history unprompted. When a commit _is_ requested: one logical change per commit, imperative subject under ~72 chars, body explaining **why** when the diff doesn't show it. Run `cargo +nightly fmt && cargo clippy && cargo test` before handing work back, committed or not.

## Conventions

- No comments in code, unless logic is really non-obvious. Comments describe _current_ state, not what's changed.
- **Single source of truth**: `MusicPlayer` (`app/state.rs`) holds all state; `view()` is pure over `&MusicPlayer` — no `Rc<RefCell<Backend>>`, no sync methods. `MusicPlayer` is NOT `Clone` (channels).
- **Async**: `mpsc` channels for cross-thread results (backend, media controls); `Task`/`Subscription` for timer tick + raw events; shared state via `&mut self`.
- `notify()` / `notify_error()` for user-facing errors; `notify_tracks(verb, n, suffix)` for pluralized counts. Persistence goes through the `JsonStore` trait (`data/mod.rs`): implementors declare only `FILE`.

## Architecture

```
src/
├── main.rs            # Entry point
├── app.rs             # Module index: declares submodules + re-exports public types (MusicPlayer, Message, …)
├── app/state.rs       # MusicPlayer (all state) + new()/Default + pane/view accessors + view()
├── app/pane.rs        # Pane (per-pane nav history + search bar + lyrics) + SplitNode tiling tree
├── app/lyrics_state.rs # LyricsState + LyricsViewMode (per-pane lyrics state)
├── app/dialog.rs      # Dialog (exclusive overlay) + accessors
├── app/edit_track.rs  # EditTrackState (editing working copy) + EditManualSearch (its manual-search step)
├── app/playlist_picker.rs # PlaylistJump (Ctrl+K jumper; doubles as add-to-playlist when pending)
├── app/shortcuts.rs   # In-app cheatsheet table (?/F1, Dialog::Shortcuts; labels via Strings)
├── app/shortcut.rs    # Shortcut (key chords decoded at event level; apply_shortcut in update/input.rs)
├── app/view_data.rs   # ViewData / ViewKind (per-view state)
├── app/message.rs     # Message + BackendResult (pane-scoped messages carry PaneId)
├── app/interaction.rs # TrackPos (+pane), DragState, ContextMenuState (tracks), CardMenuState (cards)
├── app/import.rs      # ImportPlaylistDialog + filename-pattern matching/conflict engine
├── app/translate_dialog.rs # TranslateDialog (AI-translate popup: language + prompt + in-flight flag)
├── app/ui/            # Pure functional view (mod, styles, content, playbar, queue, sidebar, split, track_list)
├── app/ui/overlays/   # Window overlays: mod (dialog dispatch + shared chrome) + one file per dialog (edit, menus, playlist, import, translate, deps, shortcuts)
├── app/update/        # Per-domain handlers (actions, artist, dispatch, drag, edit_track, input, navigation, operation, playback, playlists, search, selection, session, settings, tick, translate); dispatch.rs holds update()/subscription()
├── audio/mod.rs       # AudioPlayer: rodio sink + yt-dlp process management
├── audio/growing.rs   # GrowingMediaSource (the still-growing file reader)
├── audio/symphonia_source.rs # SymphoniaStreamingSource (rodio Source + Iterator); applies the normalization gain
├── audio/normalization.rs # compute_normalization_gain: RMS-based loudness analysis via symphonia
├── data/mod.rs        # JsonStore trait + config_path()/cache_path()
├── data/              # cache, config, downloads, playlists, library, search_history, session, thumbnails, lyrics_cache, trashbin
├── theme/             # ThemeKind presets (default Misty Forest) + AccentKind override + CornerStyle (radius_*() scale) + Palette/AppTheme (mod.rs), constants (layout.rs, re-exported), Catalog impls (catalog.rs)
├── providers/         # Provider types + dispatch (mod.rs) and per-provider backends (bandcamp, lastfm, musicbrainz, soundcloud, youtube)
├── media_controls.rs  # OS media controls via souvlaki (MPRIS/SMTC/Now Playing)
├── types.rs           # Track, TrackSource, PlayQueue
├── lyrics.rs          # LyricsProvider enum + LyricsClient (provider registry)
├── translate.rs       # AI translation via OpenAI-compatible chat completions (hosted or Ollama-local)
├── icons.rs           # SVG embedding via include_bytes! + icon()
├── load_state.rs      # LoadState<T, E>: Ready/Failed/Loading fetch-state wrapper
└── util.rs            # format_duration, fuzzy_match, remove_at, reorder_tracks
```

## State Management

- **`MusicPlayer`** (`app/state.rs`): the single source of truth. Holds audio/queue/playlists/trashbin/config, mpsc channels, `DragState`, `dialog: Option<Dialog>` (exclusive overlay), `download_registry`, `stream_cache`, `thumbnail_index`, `track_list_search` (in-list Ctrl+F: owning pane + kind, query, matches), `panes: HashMap<PaneId, Pane>` + `split_root: SplitNode` + `focused_pane_id` (tiled views; sidebar/queue/playbar global). **All per-view state** lives in `view_data`; no separate `View`/`RadioKind` enum.
- **`Pane`** (`app/pane.rs`): per-pane `nav_history` (capped at 20), search-bar state, `lyrics: Option<LyricsState>`. Splitting forks the pane (lyrics included; dropdowns reset); `SplitNode` is an equally-weighted `Leaf`/`Row`/`Column` tree (max 4 panes, `SplitDir::Horizontal` = side-by-side); `focused_pane_id` receives sidebar clicks, pane hover, and keyboard nav.
- **Virtual panes** (`app/pane.rs`): `QUEUE_PANE_ID` / `RECENT_PANE_ID` / `MANUAL_SEARCH_PANE_ID` (`u64::MAX` / `MAX-1` / `MAX-2`, never in `panes`) address the queue, recent and Edit-popup-manual-search lists, so every list is just a `PaneId` — no separate list tag. Helpers: `pane_first_index()` (1 for queue, whose now-playing row renders outside the scrollable), `pane_slot()`, `is_main_pane()`. Scroll widget ids fold through `track_list_id(pane)` (virtual panes map to their fixed list ids) and geometry is read back through `CaptureBounds::list_geo(pane)`, so scroll ops can't hit the wrong list.
- **`TrackPos`** (`app/interaction.rs`): `{ index, pane }` — an index is only meaningful against its list, so they travel together (a main pane id or a virtual one; navigation messages for virtual rows resolve `focused_pane_id`). Carried by `TrackPressed`/`TrackRightClicked`/`PlayTrackAt`/`ContextMenuPlayTrack`, `DragState`'s `pressed` (`Pressed::Track`), `last_click`, and the `get_track_at`/`toggle_selection` accessors — pass this instead of a loose `(usize, PaneId)` pair.
- **Selection / list access** (`app/update/selection.rs`): `selection_in`, `toggle_selection`, `clear_selection`, `view_tracks_in`, `get_track_at`, `track_count_in` — keyed by pane alone; virtual ids hit the queue/recent stores, `MANUAL_SEARCH_PANE_ID` the popup's results. `selection_mut_in` returns `Option` because a virtual list can vanish under a stale row message.
- **`DragState`** (`app/interaction.rs`): `pressed` (dragged thing), `hovered` (cursor target; `Track` doubles as keyboard focus), `dragged` (indices resolved at press time). `drop_target`: `Track`/`Playlist`/`Library` (insertion line), `PlaylistAdd`, `PlaylistReorder`. Same-pane reorders; cross-list/pane copies move all selected; accessors `hovered_track()`/`set_hovered*`, cleaned via `cleanup()`.
- **Scroll offsets** (`app/update/operation.rs`): one `ScrollTarget` (Tracks/Cards/CardRow/Library) names both directions of a scrollable — `CaptureBounds::slot()` classifies an id into it during the capture pass, `Message::Scrolled(ScrollTarget, Vector)` refreshes it live between passes, `scroll_offset()` reads it back for click anchoring, and `forget_pane()` drops a closed pane's captures.
- **`ContextMenuState`**: `pos: TrackPos` + selection-aware `target_indices` (ops apply to all selected if the right-clicked track is selected, else just it; "Play"/radio target only it; `Recent` tracks come from `recently_played`). Right-click focuses the source pane. A menu opened from inside a dialog (the Edit popup's manual search) stashes it in `return_to` — drawn *underneath* the menu by `view_dialog_overlay` — and `close_context_menu`/`take_context_menu` hand it back, so the single-overlay `Dialog` slot survives; that list also drops the `Edit` entry (it would replace the editor it came from).
- **Card menus** (`CardMenuState` + `CardAction`, `Dialog::CardMenu`): right-click on an artist/album/playlist card (search card tab, artist page section, sidebar library row) → `Open` (the exact `ViewKind` the card's click opens, so albums keep badge/date), `Open in browser` (only when the provider advertised a page), `Save as playlist` (albums/playlists only; reuses `create_playlist_from_card`) and `Add to library`/`Remove from library` (one `ToggleLibrary` entry whose label flips on `LibraryStore::contains`). The menu stores only that `ViewKind` and every entry reads the card off it through `ViewKind::card_ref()` / `library_item()`, so provider/kind/id/title/artwork/page live in one place. Both menus share `MenuAnchor` (cursor anchor, window-edge flip, hover focus) and the `CaptureContextMenu` geometry, so only the entry list differs.
- **"Open in browser"** funnels through `open_in_browser()` from every entry (track menu, card menu, browse/artist header buttons, each rendered only when the view has a page). A page's address comes from the `url` carried on `CardData`/`ArtistAlbumCard`/`RelatedArtistCard`/`LibraryItem`/`ViewKind`, or from `ProviderId::artist_page_url(id)` / `album_page_url(id)` when it can be rebuilt from the id alone (the same rules YouTube's card urls use; SoundCloud/Bandcamp identify by numeric id, so those pages simply have none). `ArtistIdResolved` fills one in again for pages opened by name, so a page reached from a track keeps its button.
- **Edit Track popup** (`app/update/edit_track.rs`): `EditTrackState` is the working copy (title/artist/source + the original track at its `TrackPos`); the automatic "Find" merges a resolved identity via `EditTrackProviderResolved/Error`. Its "Manual search" buttons open `EditManualSearch` (provider, scope, query, `LoadState<Vec<Track>>`, one-entry `selection`, request id) as a nested step that takes over the popup body: opening it runs the seeded query, a scope chip change re-runs it (as the search bar's chips do), Escape backs out instead of closing the popup, and results arrive as `ManualSearchResults { rid, results }` (dropped if the query was superseded; also re-captures the geometry the rows are virtualized off). The results are an ordinary track list under `MANUAL_SEARCH_PANE_ID`, so hover, now-playing highlight, keyboard nav, right-click and play all come from the shared machinery — picking is just that list's selection, capped at one entry in `toggle_selection`. Confirm assigns the picked identity for that provider (making it the source) and fills title/artist only while blank.
- **`BackendResult`** (mpsc): `SearchResults`, `SearchResultsAppend`, `RadioResults`, `DownloadComplete(Track,String)`, `DownloadError`, `SearchError(u64, String)` (the rid routes to the requesting pane's slot), `ThumbnailDownloaded(provider, id)`, `LyricsFetched(Result<Lyrics, String>, String, LyricsProvider)` (applies to lyrics panes waiting on that track+provider; tick refetches per pane on track change), `NormalizationComputed(String, f32)` (in-memory per-track gain, read on subsequent plays), `CardPlaylistReady(usize, String, Vec<Track>)` (a dragged card became a playlist), `TranslationDone/Error` (AI translation opens in the custom-lyrics editor under the target language). Tick drains → `process_result` (unconditional 1Hz tick).
- **Media controls**: souvlaki thread → `media_event_tx` → boot `Task::stream` bridge emits `Message::MediaEvent` on arrival (push, no tick polling); `MediaUpdate` flows main → thread.

## Data Flow & Navigation

- User → `Message` → `update()` → handler (spawns bg thread or mutates state). Tick drains `result_rx` → `process_result` (unconditional 1Hz tick); syncs audio, detects stream end → auto-next, sends media-control updates, re-anchors progress. Playback position is a `(progress, Instant)` anchor interpolated with the wall clock — the canvas progress bar animates from it at draw time with no view rebuilds. `view()` reads `&MusicPlayer`. Cursor tracking subscribes only while a press is down (drag); track rows and cards report right-clicks with position via `RightClickArea<P>` (payload + `fn` to the message; a card's payload is a `CardTarget`, which names the `ScrollTarget` it sits in so the click can undo that scrollable's offset — iced shifts a scrolled child by the whole translation vector — plus the artist-page shelf it rides in, if any) and search-input clicks report their pane, so idle mouse movement emits nothing.
- `nav_history: Vec<ViewData>` + `nav_history_pos` per pane; Back if `pos > 0`, Forward if `pos + 1 < len`. `\` splits side-by-side, `Shift+\` stacks, `Ctrl+W`/header `X` closes (max 4 panes), `Ctrl`+Arrows move focus between adjacent panes with wraparound holding row/column (`SplitNode::neighbor`, `wrap_edge`); sidebar clicks, `/`, and keyboard nav target the focused pane (click or hover any pane to focus; `push_new_view` focuses its pane). `handle_navigate_to(pane, data)` truncates at `pos+1`, installs the target (no-op self-nav skipped via `ViewData::same_kind`), pushes, advances `pos`.
- Results route by request id to the requesting pane's slot (`slot_for_request` scans all panes). `SearchResultsAppend` syncs in place; "Load More" hidden once a page returns < `SEARCH_PAGE_SIZE`. `Downloads` renders `ViewData.tracks` (synced from `DownloadRegistry` in tick); `Playlist` tracks read from `PlaylistStore` via `view_tracks_in`.

## UI Layout

- **Sidebar** (`SIDEBAR_WIDTH = 300.0`): nav buttons (Search/Downloads/Trashbin), scrollable playlist list, create-playlist input, local import. **Main**: `SplitNode` tiling of panes, each with its own search bar + view (Search / Radio / Artist / Album / Playlist / Downloads / Trashbin / Lyrics); split panes show a header, single-pane mode has none. **Queue panel** (`QUEUE_MIN_WIDTH = 240.0`); **Playbar**: track info, progress, controls, volume. **Overlays** (exclusive `Dialog`, drop indicator, per-pane search-history dropdown, toast) via `iced::widget::Stack`.

## iced API Notes

- `bg_*()` / `button_style_*` → `impl Fn(&AppTheme) -> container::Style` (in `ui/styles.rs`); `slider_style()` via `AppTheme` `slider::Catalog`. `Vertical::Top` (not `::Start`); `rule::horizontal(height)` for dividers.
- Icons: `include_bytes!` + `icon(data,color,size)` → `svg::Svg::new(svg::Handle::from_memory(data))`. `Text` uses `.center()`/`.align_x()`/`.align_y()`; `Button::on_press_maybe(Option<Message>)` for disabled.
- `event::listen_with()` takes an `fn` pointer; `Subscription::batch` (not `::chain`). `Stack` for overlays; `MouseArea::on_move` for hover; `scrollable` `.on_scroll()`; `operation::scroll_to`/`scroll_by`.

## Audio Pipeline

`AudioPlayer` runs a dedicated output thread (mpsc command channel). Decoding is fully native via symphonia.

- **Stream+cache**: `yt-dlp -f bestaudio[ext=m4a]/bestaudio/best[ext=mp4]/best -o -` writes AAC audio (muxed MP4 fallback for age-restricted tracks, whose AAC symphonia still decodes) to the cache file (`.cache`, owned by `StreamCache`); a copy thread drains stdout and flips `writer_alive` when done. When yt-dlp and that thread both finish, the tick registers the cache; track end → sink empties → auto-advance.
- **Decoding**: a custom `SymphoniaStreamingSource` (rodio `Source` + `Iterator<Item=i16>`) wraps a non-seekable `GrowingMediaSource`, so symphonia demuxes sequentially and plays a still-growing file without `rodio::Decoder::new`'s `SeekError`. The reader blocks at EOF while `writer_alive`, so playback starts within a few KB. Cached/downloaded/local (`PlayCached`) reuse it with `writer_alive = None` (real `byte_len`) so seeking works on replay.
- **Volume normalization** (optional `config.volume_normalization`): a per-track RMS/peak gain from `compute_normalization_gain`, applied per-sample inside `SymphoniaStreamingSource` (composes with `set_volume`, survives seeking). First play uses gain 1.0; `request_normalization_analysis` fills the cache afterwards.

## YouTube & Key Files

- `search()`/`browse()`: YouTube scoped search via `ytmusicapi` (`youtube_search.py`), `scope` → ytmusicapi `filter=`; YouTube pagination (`search_more`) falls back to `yt-dlp --flat-playlist`. `browse()` is dispatched by `ProviderId`: YouTube drills via `get_artist`/`get_album`/`get_playlist`; SoundCloud's songs/artists/albums/playlists search and drill-downs all use the `rsoundcloud` crate (no API key; artist browse → `get_user_tracks`, album/playlist → `get_playlist_tracks`; `yt-dlp` only for the actual stream/download, since rsoundcloud exposes no plain stream URL); Bandcamp uses the `bandcamp` crate (async, via a shared multi-thread runtime; Songs scope merges direct track hits with album expansions fetched concurrently in a thread scope; keyless with direct 128k MP3 `streaming_url`s, so it streams over plain HTTP and downloads without `yt-dlp`; artwork uses `Px300` (`_4.jpg`, ~34KB) instead of `Full` originals (~2.4MB) that stall the thumbnail pipeline); Last.fm is hand-rolled `ureq` against `ws.audioscrobbler.com` (no crate covers catalog search; ships a bundled app key; search-only like MusicBrainz but with radio via `track.getsimilar`; all failures propagate as errors so a missing/invalid key shows a toast instead of an empty list; `track.search` serves one generic star placeholder for everything, so it is filtered out and Songs results are enriched with real album art via `track.getInfo` plus an artist top-album fallback, both in parallel `thread::scope`s); MusicBrainz uses `musicbrainz_rs` (`MbRecording::browse().by_artist()` for artist pages, `MbRelease::fetch().with_recordings()` for albums — the bare `artist/{id}/recordings` and `release/{id}/recordings` endpoints do NOT return recordings). Artists/Albums scopes return `CardData` (`SearchTab::Artists`/`Albums`), not fake `Track` stubs — only `Songs` produces playable tracks. `SEARCH_PAGE_SIZE = 10`.
- A blank/whitespace query is a browse, not a search: YouTube serves the global charts (`get_charts`), SoundCloud/MusicBrainz their trending hits, and `run_search` no longer blocks empty queries (blank ones are skipped in search history and the page is marked exhausted — no pagination).
- `radio_song()`/`radio_artist()`: YouTube uses ytmusicapi's watch-playlist engine (`watch` mode, seeded by `video_id`/`browseId`, no yt-dlp fallback — needs Python + ytmusicapi); Last.fm uses `track.getsimilar` / top-tracks of similar artists; `download()`/`download_audio()` → `yt-dlp --extract-audio` MP3.
- **Artist page**: `ViewKind::Artist(ArtistEntry { id, name, source, page })` carries a serializable `ArtistPageState` (`providers/artist_page.rs`) — known per-provider artist ids, header, and a `sections: [ArtistSection; 4]` array indexed by `ArtistSectionKind` (each: selected provider + `LoadState<SectionContent>`); section ops (`start_section_load`, `serve_cached_section`, `merge_kind`, `fail_section`, `card_thumbs`) live on the type. `spawn_artist_kinds_fetch(provider, id, kinds)` (`ArtistDataKind`: Header/Popular/Albums/Playlists/Related) fetches only the requested pieces and delivers them incrementally — YT/MusicBrainz/Bandcamp/Last.fm answer in one call and split it, SoundCloud runs each endpoint as its own tokio task so sections land (and fail) independently. `open_artist()` loads the source provider's full page plus a Header-only companion fetch for each other header-capable provider, in parallel; a section-picker switch serves from cache when covered, else loads just that kind. Results arrive as `BackendResult::ArtistIdResolved` + one `ArtistSectionLoaded` per kind and merge into the section currently selecting that provider; fetched kinds accumulate per provider in `CachedArtistPage` (page + which kinds arrived) so switching back is request-free. Popular tracks double as the view's track list.
- `ViewKind` (`app/view_data.rs`): `Search(SearchData)`/`SongRadio(RadioData)`/`ArtistRadio(RadioData)`/`Artist`/`Album(BrowseRef)`/`PlaylistView(BrowseRef)`/`Playlist(PlaylistEntry)`/`Downloads`/`Trashbin`/`Settings`. Variants hold data structs; callers destructure `kind` once and read child fields directly (no per-field accessor methods). `Trashbin` reads live from `TrashStore` (kept in queue but skipped at track-change time, unplayable in place). `RadioData` (seed title + header thumbnail key) renders through the shared `view_track_page` header with browse pages.
- `load_state.rs`: `LoadState<T, E = String>` (`Ready(T)` / `Failed(E)` / `Loading`) — used by `ViewData.content` (tracks + loading + error), `ArtistSection.state`, `LyricsState.lyrics` and the manual-search results. `util.rs`: `format_duration`, `fuzzy_match`, `plural_suffix`, `try_probe_duration`, `remove_at`, `reorder_tracks` (unit-tested).

## Maintenance

Keep `AGENTS.md` under ~150 lines and in sync after structural changes: new/removed files, renamed types/functions, module layout, keyboard shortcuts (`app/update/input.rs`), config fields (`data/config.rs`), on-disk paths (`data/*.rs` `FILE` consts), external tool requirements, or the audio pipeline.

- **i18n** (`src/i18n/`): all UI strings live in one `Strings` struct (`mod.rs`); each locale is a module exposing `pub const STRINGS: Strings` (copy `en.rs` and translate). Add a language by creating `src/i18n/<code>.rs` and appending one entry to the `languages!` macro in `mod.rs` — the `Language` enum, `label()`, and `strings()` are generated from it, so `config.language`, the Settings picker, and `view()` need no other edits. Parameterized/pluralized messages are `fn` fields (e.g. `added`/`n_saved`) so each locale owns word order and plural forms.