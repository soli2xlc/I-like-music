//! Application theme: the color [`Palette`], the [`AppTheme`] wrapper iced
//! widgets are parameterized over, and the layout tokens re-exported from
//! [`layout`].

use std::sync::atomic::{AtomicU32, Ordering};

use iced::{theme, Color, Theme};
use serde::{Deserialize, Serialize};

mod catalog;
pub mod layout;

pub use layout::*;

/// Which [`Palette`] the [`AppTheme`] should use. Persisted in [`Config`]
/// so the user's choice survives restarts.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum ThemeKind {
    #[default]
    MistForest,
    MistMorning,
    Dark,
    Light,
    Midnight,
    Dusk,
}

impl ThemeKind {
    pub const ALL: [ThemeKind; 6] = [
        ThemeKind::MistForest,
        ThemeKind::MistMorning,
        ThemeKind::Dark,
        ThemeKind::Light,
        ThemeKind::Midnight,
        ThemeKind::Dusk,
    ];

    pub fn label(self) -> &'static str {
        match self {
            ThemeKind::MistForest => "Misty Forest",
            ThemeKind::MistMorning => "Misty Morning",
            ThemeKind::Dark => "Dark",
            ThemeKind::Light => "Light",
            ThemeKind::Midnight => "Midnight",
            ThemeKind::Dusk => "Dusk",
        }
    }

    pub fn palette(self) -> Palette {
        match self {
            ThemeKind::MistForest => Palette::mist_forest(),
            ThemeKind::MistMorning => Palette::mist_morning(),
            ThemeKind::Dark => Palette::dark(),
            ThemeKind::Light => Palette::light(),
            ThemeKind::Midnight => Palette::midnight(),
            ThemeKind::Dusk => Palette::dusk(),
        }
    }
}

/// Optional accent colour that replaces the one defined by the chosen
/// [`ThemeKind`]. `Theme` keeps the theme's own accent.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum AccentKind {
    #[default]
    Theme,
    Sage,
    Green,
    Blue,
    Amber,
    Rose,
    Violet,
}

impl AccentKind {
    pub const ALL: [AccentKind; 7] = [
        AccentKind::Theme,
        AccentKind::Sage,
        AccentKind::Green,
        AccentKind::Blue,
        AccentKind::Amber,
        AccentKind::Rose,
        AccentKind::Violet,
    ];

    pub fn label(self) -> &'static str {
        match self {
            AccentKind::Theme => "Theme",
            AccentKind::Sage => "Sage",
            AccentKind::Green => "Green",
            AccentKind::Blue => "Blue",
            AccentKind::Amber => "Amber",
            AccentKind::Rose => "Rose",
            AccentKind::Violet => "Violet",
        }
    }

    /// `(for dark themes, for light themes)`; `None` keeps the theme accent.
    fn colors(self) -> Option<(Color, Color)> {
        let pair = |dark: (u8, u8, u8), light: (u8, u8, u8)| {
            Some((
                Color::from_rgb8(dark.0, dark.1, dark.2),
                Color::from_rgb8(light.0, light.1, light.2),
            ))
        };
        match self {
            AccentKind::Theme => None,
            AccentKind::Sage => pair((0x9d, 0xb3, 0x91), (0x5d, 0x78, 0x55)),
            AccentKind::Green => pair((0x2f, 0xd0, 0x8a), (0x1f, 0x9d, 0x63)),
            AccentKind::Blue => pair((0x6e, 0xa8, 0xfe), (0x2f, 0x6f, 0xd0)),
            AccentKind::Amber => pair((0xe5, 0xa9, 0x4f), (0xb8, 0x75, 0x14)),
            AccentKind::Rose => pair((0xf0, 0x8c, 0xa8), (0xc2, 0x47, 0x6b)),
            AccentKind::Violet => pair((0xb4, 0x97, 0xf5), (0x7a, 0x55, 0xd6)),
        }
    }

    pub fn apply(self, mut p: Palette) -> Palette {
        let Some((on_dark, on_light)) = self.colors() else {
            return p;
        };
        let dark = luminance(p.bg) < 0.5;
        let accent = if dark { on_dark } else { on_light };
        p.accent = accent;
        p.accent_hover = blend_colors(accent, Color::BLACK, 0.12);
        p.fg_accent = if dark {
            accent
        } else {
            blend_colors(accent, Color::BLACK, 0.15)
        };
        p.bg_current = blend_colors(p.bg, accent, if dark { 0.22 } else { 0.30 });
        p.fg_on_accent = if luminance(accent) > 0.6 {
            Color::BLACK
        } else {
            Color::WHITE
        };
        p
    }
}

/// How rounded buttons, cards and dialogs are drawn.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum CornerStyle {
    Sharp,
    #[default]
    Normal,
    Round,
}

impl CornerStyle {
    pub const ALL: [CornerStyle; 3] = [CornerStyle::Sharp, CornerStyle::Normal, CornerStyle::Round];

    pub fn label(self) -> &'static str {
        match self {
            CornerStyle::Sharp => "Sharp",
            CornerStyle::Normal => "Normal",
            CornerStyle::Round => "Round",
        }
    }

    fn scale(self) -> f32 {
        match self {
            CornerStyle::Sharp => 0.0,
            CornerStyle::Normal => 1.0,
            CornerStyle::Round => 1.6,
        }
    }
}

static CORNER_SCALE_BITS: AtomicU32 = AtomicU32::new(0x3f80_0000);

pub fn set_corner_style(style: CornerStyle) {
    CORNER_SCALE_BITS.store(style.scale().to_bits(), Ordering::Relaxed);
}

fn corner_scale() -> f32 {
    f32::from_bits(CORNER_SCALE_BITS.load(Ordering::Relaxed))
}

pub fn radius_sm() -> f32 {
    RADIUS_SM * corner_scale()
}

pub fn radius_md() -> f32 {
    RADIUS_MD * corner_scale()
}

pub fn radius_lg() -> f32 {
    RADIUS_LG * corner_scale()
}

fn luminance(c: Color) -> f32 {
    0.299 * c.r + 0.587 * c.g + 0.114 * c.b
}

/// The palette for a theme with the user's accent override applied.
pub fn build_palette(kind: ThemeKind, accent: AccentKind) -> Palette {
    accent.apply(kind.palette())
}

#[derive(Debug, Clone, Copy)]
pub struct Palette {
    pub bg: Color,
    pub bg_secondary: Color,
    pub bg_tertiary: Color,
    pub bg_hover: Color,
    pub bg_current: Color,
    pub accent: Color,
    pub accent_hover: Color,
    pub button: Color,
    pub button_hover: Color,
    pub fg: Color,
    pub fg_accent: Color,
    pub fg_secondary: Color,
    pub fg_muted: Color,
    pub overlay: Color,
    pub danger: Color,
    pub danger_hover: Color,
    pub fg_on_accent: Color,
    pub fg_on_danger: Color,
}

impl Default for Palette {
    fn default() -> Self {
        Self::mist_forest()
    }
}

fn blend_channels(c1: f32, c2: f32, ratio: f32) -> f32 {
    c1 * (1.0 - ratio) + c2 * ratio
}

pub fn blend_colors(c1: Color, c2: Color, ratio: f32) -> Color {
    Color::from_rgba(
        blend_channels(c1.r, c2.r, ratio),
        blend_channels(c1.g, c2.g, ratio),
        blend_channels(c1.b, c2.b, ratio),
        blend_channels(c1.a, c2.a, ratio),
    )
}

impl Palette {
    pub const fn mist_forest() -> Self {
        Self {
            bg: Color::from_rgb8(0x1b, 0x1c, 0x19),
            bg_secondary: Color::from_rgb8(0x23, 0x25, 0x20),
            bg_tertiary: Color::from_rgb8(0x12, 0x13, 0x11),
            bg_hover: Color::from_rgb8(0x33, 0x36, 0x2f),
            bg_current: Color::from_rgb8(0x2c, 0x38, 0x2b),
            accent: Color::from_rgb8(0x9d, 0xb3, 0x91),
            accent_hover: Color::from_rgb8(0x8a, 0xa1, 0x7e),
            button: Color::from_rgb8(0x32, 0x35, 0x2e),
            button_hover: Color::from_rgb8(0x43, 0x47, 0x3e),
            fg: Color::from_rgb8(0xd8, 0xd9, 0xd6),
            fg_accent: Color::from_rgb8(0xae, 0xc2, 0xa3),
            fg_secondary: Color::from_rgb8(0x9a, 0x9c, 0x94),
            fg_muted: Color::from_rgb8(0x62, 0x64, 0x5c),
            overlay: Color::from_rgba8(0, 0, 0, 0.7),
            danger: Color::from_rgb8(0xb8, 0x6a, 0x5c),
            danger_hover: Color::from_rgb8(0xa8, 0x5a, 0x4d),
            fg_on_accent: Color::from_rgb8(0x14, 0x16, 0x0f),
            fg_on_danger: Color::WHITE,
        }
    }

    pub const fn mist_morning() -> Self {
        Self {
            bg: Color::from_rgb8(0xe6, 0xe7, 0xe4),
            bg_secondary: Color::from_rgb8(0xd9, 0xda, 0xd6),
            bg_tertiary: Color::from_rgb8(0xcc, 0xcd, 0xc8),
            bg_hover: Color::from_rgb8(0xbf, 0xc1, 0xba),
            bg_current: Color::from_rgb8(0xc7, 0xd3, 0xbe),
            accent: Color::from_rgb8(0x5d, 0x78, 0x55),
            accent_hover: Color::from_rgb8(0x4e, 0x68, 0x47),
            button: Color::from_rgb8(0xc4, 0xc6, 0xbf),
            button_hover: Color::from_rgb8(0xb4, 0xb7, 0xae),
            fg: Color::from_rgb8(0x20, 0x22, 0x1d),
            fg_accent: Color::from_rgb8(0x46, 0x62, 0x3f),
            fg_secondary: Color::from_rgb8(0x55, 0x58, 0x4f),
            fg_muted: Color::from_rgb8(0x8a, 0x8d, 0x83),
            overlay: Color::from_rgba8(0, 0, 0, 0.5),
            danger: Color::from_rgb8(0xa8, 0x48, 0x3c),
            danger_hover: Color::from_rgb8(0x98, 0x3b, 0x30),
            fg_on_accent: Color::WHITE,
            fg_on_danger: Color::WHITE,
        }
    }

    pub const fn midnight() -> Self {
        Self {
            bg: Color::from_rgb8(0x10, 0x13, 0x1c),
            bg_secondary: Color::from_rgb8(0x16, 0x1a, 0x26),
            bg_tertiary: Color::from_rgb8(0x0a, 0x0c, 0x13),
            bg_hover: Color::from_rgb8(0x26, 0x2c, 0x3d),
            bg_current: Color::from_rgb8(0x1c, 0x2c, 0x4a),
            accent: Color::from_rgb8(0x6e, 0xa8, 0xfe),
            accent_hover: Color::from_rgb8(0x5a, 0x96, 0xee),
            button: Color::from_rgb8(0x26, 0x2c, 0x3d),
            button_hover: Color::from_rgb8(0x35, 0x3d, 0x54),
            fg: Color::from_rgb8(0xdf, 0xe3, 0xec),
            fg_accent: Color::from_rgb8(0x7f, 0xb2, 0xff),
            fg_secondary: Color::from_rgb8(0x8a, 0x92, 0xa8),
            fg_muted: Color::from_rgb8(0x55, 0x5c, 0x70),
            overlay: Color::from_rgba8(0, 0, 0, 0.7),
            danger: Color::from_rgb8(0xd0, 0x5a, 0x5a),
            danger_hover: Color::from_rgb8(0xc0, 0x4a, 0x4a),
            fg_on_accent: Color::from_rgb8(0x0b, 0x12, 0x20),
            fg_on_danger: Color::WHITE,
        }
    }

    pub const fn dusk() -> Self {
        Self {
            bg: Color::from_rgb8(0x1d, 0x18, 0x16),
            bg_secondary: Color::from_rgb8(0x26, 0x20, 0x1d),
            bg_tertiary: Color::from_rgb8(0x13, 0x0f, 0x0e),
            bg_hover: Color::from_rgb8(0x3a, 0x30, 0x2b),
            bg_current: Color::from_rgb8(0x4a, 0x2e, 0x1c),
            accent: Color::from_rgb8(0xe0, 0xa0, 0x60),
            accent_hover: Color::from_rgb8(0xd0, 0x8f, 0x4c),
            button: Color::from_rgb8(0x3a, 0x30, 0x2b),
            button_hover: Color::from_rgb8(0x4b, 0x3f, 0x38),
            fg: Color::from_rgb8(0xe8, 0xde, 0xd6),
            fg_accent: Color::from_rgb8(0xea, 0xb0, 0x70),
            fg_secondary: Color::from_rgb8(0xa3, 0x94, 0x8a),
            fg_muted: Color::from_rgb8(0x6b, 0x5f, 0x57),
            overlay: Color::from_rgba8(0, 0, 0, 0.7),
            danger: Color::from_rgb8(0xc8, 0x5c, 0x50),
            danger_hover: Color::from_rgb8(0xb8, 0x4e, 0x42),
            fg_on_accent: Color::from_rgb8(0x1a, 0x10, 0x08),
            fg_on_danger: Color::WHITE,
        }
    }

    pub const fn dark() -> Self {
        Self {
            bg: Color::from_rgb8(0x14, 0x14, 0x18),
            bg_secondary: Color::from_rgb8(0x1a, 0x1a, 0x20),
            bg_tertiary: Color::from_rgb8(0x08, 0x08, 0x0e),
            bg_hover: Color::from_rgb8(0x2a, 0x2a, 0x34),
            bg_current: Color::from_rgb8(0x0a, 0x3a, 0x20),
            accent: Color::from_rgb8(0x14, 0xc8, 0x84),
            accent_hover: Color::from_rgb8(0x10, 0xba, 0x70),
            button: Color::from_rgb8(0x2a, 0x2a, 0x34),
            button_hover: Color::from_rgb8(0x3a, 0x3a, 0x44),
            fg: Color::from_rgb8(0xe0, 0xe0, 0xe0),
            fg_accent: Color::from_rgb8(0x14, 0xc8, 0x84),
            fg_secondary: Color::from_rgb8(0x88, 0x88, 0xa0),
            fg_muted: Color::from_rgb8(0x55, 0x55, 0x60),
            overlay: Color::from_rgba8(0, 0, 0, 0.7),
            danger: Color::from_rgb8(0xc0, 0x40, 0x40),
            danger_hover: Color::from_rgb8(0xc0, 0x30, 0x30),
            fg_on_accent: Color::BLACK,
            fg_on_danger: Color::WHITE,
        }
    }

    pub const fn light() -> Self {
        Self {
            bg: Color::from_rgb8(0xf6, 0xf6, 0xfa),
            bg_secondary: Color::from_rgb8(0xea, 0xea, 0xf0),
            bg_tertiary: Color::from_rgb8(0xdf, 0xdf, 0xe8),
            bg_hover: Color::from_rgb8(0xd5, 0xd5, 0xe0),
            bg_current: Color::from_rgb8(0xa0, 0xf0, 0xa0),
            accent: Color::from_rgb8(0x84, 0xe8, 0xa4),
            accent_hover: Color::from_rgb8(0x60, 0xe8, 0x80),
            button: Color::from_rgb8(0xc8, 0xc8, 0xd2),
            button_hover: Color::from_rgb8(0xb8, 0xb8, 0xc8),
            fg: Color::from_rgb8(0x18, 0x18, 0x20),
            fg_accent: Color::from_rgb8(0x04, 0x98, 0x34),
            fg_secondary: Color::from_rgb8(0x55, 0x55, 0x66),
            fg_muted: Color::from_rgb8(0x88, 0x88, 0x99),
            overlay: Color::from_rgba8(0, 0, 0, 0.5),
            danger: Color::from_rgb8(0xf0, 0x70, 0x70),
            danger_hover: Color::from_rgb8(0xe0, 0x60, 0x60),
            fg_on_accent: Color::BLACK,
            fg_on_danger: Color::WHITE,
        }
    }
}

impl From<ThemeKind> for Palette {
    fn from(kind: ThemeKind) -> Self {
        kind.palette()
    }
}
/// A custom iced theme that wraps the built-in [`iced::Theme`] for
/// widget-level styling (so all widget `Catalog` traits are satisfied)
/// while also exposing our rich [`Palette`] for custom style closures.
///
/// By using `AppTheme` as the `Theme` type parameter of iced widgets,
/// style closures receive `&AppTheme` and can read palette colors directly
/// via `theme.palette` — eliminating the need to thread `&Palette` through
/// every view function (no props drilling).
#[derive(Debug, Clone)]
pub struct AppTheme {
    pub inner: Theme,
    pub palette: Palette,
}

impl AppTheme {
    pub fn new(palette: &Palette) -> Self {
        Self {
            inner: Theme::custom_with_fn(
                "goosemusic",
                iced::theme::Palette {
                    background: palette.bg,
                    text: palette.fg,
                    primary: palette.accent,
                    success: palette.accent,
                    warning: palette.fg_secondary,
                    danger: palette.danger,
                },
                |_| {
                    iced::theme::palette::Extended::generate(iced::theme::Palette {
                        background: palette.bg,
                        text: palette.fg,
                        primary: palette.accent,
                        success: palette.accent,
                        warning: palette.fg_secondary,
                        danger: palette.danger,
                    })
                },
            ),
            palette: *palette,
        }
    }
}

impl From<Palette> for AppTheme {
    fn from(palette: Palette) -> Self {
        Self::new(&palette)
    }
}

// Delegate theme::Base to the inner iced::Theme.
impl theme::Base for AppTheme {
    fn default(_preference: theme::Mode) -> Self {
        Self::new(&Palette::default())
    }

    fn mode(&self) -> theme::Mode {
        self.inner.mode()
    }

    fn base(&self) -> theme::Style {
        theme::Style {
            background_color: self.palette.bg,
            text_color: self.palette.fg,
        }
    }

    fn palette(&self) -> Option<iced::theme::Palette> {
        Some(self.palette.into())
    }

    fn name(&self) -> &'static str {
        "goosemusic"
    }
}

/// Maps our [`Palette`] fields onto iced's 6-color [`theme::Palette`].
impl From<Palette> for iced::theme::Palette {
    fn from(p: Palette) -> Self {
        Self {
            background: p.bg,
            text: p.fg,
            primary: p.accent,
            success: p.accent,
            warning: p.fg_secondary,
            danger: p.danger,
        }
    }
}
