use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use super::{JsonStore, StoreLocation};
use crate::types::Track;

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DownloadRegistry {
    tracks: HashMap<String, Track>,
}

impl JsonStore for DownloadRegistry {
    const FILE: &'static str = "downloads.json";
    const LOCATION: StoreLocation = StoreLocation::Data;
}

impl DownloadRegistry {
    /// Load the registry, rewriting pre-slug `Debug:id` keys (e.g.
    /// `YouTube:…`, `LastFm:…`) to the `slug:id` format used by
    /// [`Track::cache_key`] so old entries stay reachable.
    pub fn load_migrated() -> Self {
        let mut store = Self::load();
        let mut remapped = std::collections::HashMap::new();
        let mut migrated = false;
        for (old_key, track) in store.tracks.drain() {
            let new_key = track.cache_key();
            migrated |= new_key != old_key;
            remapped.entry(new_key).or_insert(track);
        }
        store.tracks = remapped;
        if migrated {
            store.save();
        }
        store
    }

    pub fn register(&mut self, track: Track) {
        self.tracks.insert(track.cache_key(), track);
        self.save();
    }

    pub fn remove(&mut self, key: &str) -> Option<Track> {
        let result = self.tracks.remove(key);
        self.save();
        result
    }

    pub fn len(&self) -> usize {
        self.tracks.len()
    }

    pub fn contains(&self, key: &str) -> bool {
        self.tracks.contains_key(key)
    }

    /// Returns the on-disk path of the downloaded audio file for `key`, if the
    /// track is registered and was downloaded to a known location.
    pub fn path_for(&self, key: &str) -> Option<String> {
        self.tracks.get(key).and_then(Track::local_path)
    }

    pub fn clone_tracks(&self) -> Vec<Track> {
        self.tracks.values().cloned().collect()
    }
}
