//! Pluggable music search/stream/download providers.
//!
//! Every source of music (`YouTube`, `SoundCloud`, `MusicBrainz`, …)
//! is described by a [`ProviderId`] plus a small set of capability flags and
//! per-provider operations. Tracks keep a `crate::types::ProviderMap`-scoped
//! set of provider-specific identifiers, so a single logical track can be
//! played/downloaded from any provider that carries it.
//!
//! The shared types and the dispatch entry points live in this module; the
//! per-provider backends (`musicbrainz`, `soundcloud`, `youtube`)
//! implement the provider-specific search/resolve/download logic and return
//! [`crate::types::Track`]s carrying that provider's id.

mod artist_page;
mod bandcamp;
pub(crate) mod lastfm;
mod musicbrainz;
mod soundcloud;
mod youtube;
pub(crate) mod ytdlp;

use std::{
    collections::HashMap,
    io::{Read, Write},
    process::{Command, Output, Stdio},
    thread,
    time::{Duration, Instant},
};

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};

use crate::types::Track;

/// Drain a child pipe to completion, returning what was read. Run it on a
/// helper thread while polling `try_wait` so a chatty child can't deadlock
/// on a full pipe (see [`run_command_with_timeout`]).
pub(crate) fn drain_pipe(pipe: Option<impl Read>) -> Vec<u8> {
    pipe.map(|mut p| {
        let mut buf = Vec::new();
        let _ = p.read_to_end(&mut buf);
        buf
    })
    .unwrap_or_default()
}

/// Run a child process to completion, killing it when it exceeds `timeout`.
/// `stdin_input`, when present, is fed to the child's stdin on its own
/// thread. stdout/stderr are drained on helper threads so a chatty child
/// can't deadlock on a full pipe while we poll `try_wait`.
pub(crate) fn run_command_with_stdin_and_timeout(
    cmd: &mut Command,
    stdin_input: Option<Vec<u8>>,
    timeout: Duration,
) -> Result<Output> {
    let program = cmd.get_program().to_string_lossy().into_owned();
    let mut child = cmd
        .stdin(if stdin_input.is_some() {
            Stdio::piped()
        } else {
            Stdio::null()
        })
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .with_context(|| format!("Failed to run {program}"))?;

    // Feed stdin on its own thread; the payload is small (a URL list), so
    // this never blocks, and a child that exits early just breaks the pipe.
    let stdin_handle = stdin_input.map(|input| {
        let stdin = child.stdin.take();
        thread::spawn(move || {
            if let Some(mut stdin) = stdin {
                let _ = stdin.write_all(&input);
            }
        })
    });

    let stdout = child.stdout.take();
    let stderr = child.stderr.take();
    let stdout_handle = thread::spawn(move || drain_pipe(stdout));
    let stderr_handle = thread::spawn(move || drain_pipe(stderr));

    let started = Instant::now();
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break status,
            Ok(None) => {
                if started.elapsed() >= timeout {
                    let _ = child.kill();
                    let _ = child.wait();
                    anyhow::bail!(
                        "{program} timed out after {}s",
                        timeout.as_secs_f32().round()
                    );
                }
                thread::sleep(Duration::from_millis(100));
            }
            Err(e) => anyhow::bail!("Failed to wait for {program}: {e}"),
        }
    };

    let stdout = stdout_handle.join().unwrap_or_default();
    let stderr = stderr_handle.join().unwrap_or_default();
    if let Some(handle) = stdin_handle {
        let _ = handle.join();
    }
    Ok(Output {
        status,
        stdout,
        stderr,
    })
}

/// Run a short-lived child process with no stdin to completion, killing it
/// when it exceeds `timeout`. Thin wrapper over
/// [`run_command_with_stdin_and_timeout`].
pub(crate) fn run_command_with_timeout(cmd: &mut Command, timeout: Duration) -> Result<Output> {
    run_command_with_stdin_and_timeout(cmd, None, timeout)
}

/// Shared HTTP agent for keyless JSON providers (Last.fm, Bandcamp).
pub(crate) fn http_agent() -> &'static ureq::Agent {
    static AGENT: std::sync::OnceLock<ureq::Agent> = std::sync::OnceLock::new();
    AGENT.get_or_init(|| {
        ureq::config::Config::builder()
            .timeout_connect(Some(std::time::Duration::from_secs(15)))
            .timeout_global(Some(std::time::Duration::from_secs(30)))
            .build()
            .new_agent()
    })
}

/// Shared multi-thread tokio runtime for async provider backends
/// (`rsoundcloud`, `bandcamp` crate). One runtime for all providers instead of
/// one per provider.
pub(crate) fn shared_runtime() -> &'static tokio::runtime::Runtime {
    static RUNTIME: std::sync::OnceLock<tokio::runtime::Runtime> = std::sync::OnceLock::new();
    RUNTIME.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .expect("Failed to build provider runtime")
    })
}

/// Ensure `dir` exists and join `{id}.mp3` — the shared download-path preamble.
pub(crate) fn download_file_path(dir: &std::path::Path, id: &str) -> std::path::PathBuf {
    let _ = std::fs::create_dir_all(dir);
    dir.join(format!("{id}.mp3"))
}

/// Identifies a music provider. Stored on tracks (which provider is the source of a
/// result) and in configuration (the default stream+download provider).
///
/// `Local` is reserved for user-imported files and is never shown in the
/// provider picker or the default-provider list.
#[derive(
    Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize, Default,
)]
pub enum ProviderId {
    #[default]
    YouTube,
    SoundCloud,
    MusicBrainz,
    Bandcamp,
    LastFm,
    Local,
}

/// Capability flags for a [`ProviderId`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct ProviderCaps {
    pub search: bool,
    pub stream: bool,
    pub download: bool,
    pub radio: bool,
}

impl ProviderId {
    /// Directory name for this provider's cached files (thumbnails, stream
    /// cache). Lowercase ASCII, safe to use as a path segment.
    pub fn slug(self) -> &'static str {
        match self {
            ProviderId::YouTube => "youtube",
            ProviderId::SoundCloud => "soundcloud",
            ProviderId::MusicBrainz => "musicbrainz",
            ProviderId::Bandcamp => "bandcamp",
            ProviderId::LastFm => "lastfm",
            ProviderId::Local => "local",
        }
    }

    /// Inverse of [`slug`](ProviderId::slug); `None` for unknown directory names.
    pub fn from_slug(slug: &str) -> Option<Self> {
        match slug {
            "youtube" => Some(ProviderId::YouTube),
            "soundcloud" => Some(ProviderId::SoundCloud),
            "musicbrainz" => Some(ProviderId::MusicBrainz),
            "bandcamp" => Some(ProviderId::Bandcamp),
            "lastfm" => Some(ProviderId::LastFm),
            "local" => Some(ProviderId::Local),
            _ => None,
        }
    }

    /// Provider-namespaced cache key (`slug:id`) for a song id. Single source
    /// of truth for every cache (stream index, downloads, lyrics,
    /// normalization) so ids from different providers cannot collide.
    pub fn cache_key(self, id: &str) -> String {
        format!("{}:{id}", self.slug())
    }

    /// Inverse of the pre-slug `Debug`-prefixed key segment (e.g. `YouTube`,
    /// `LastFm`); `None` for anything else (including current slugs). Used
    /// only by one-time migrations of persisted keys to [`cache_key`](ProviderId::cache_key).
    pub fn from_legacy_key(prefix: &str) -> Option<Self> {
        match prefix {
            "YouTube" => Some(ProviderId::YouTube),
            "SoundCloud" => Some(ProviderId::SoundCloud),
            "MusicBrainz" => Some(ProviderId::MusicBrainz),
            "Bandcamp" => Some(ProviderId::Bandcamp),
            "LastFm" => Some(ProviderId::LastFm),
            "Local" => Some(ProviderId::Local),
            _ => None,
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            ProviderId::YouTube => "YouTube",
            ProviderId::SoundCloud => "SoundCloud",
            ProviderId::MusicBrainz => "MusicBrainz",
            ProviderId::Bandcamp => "Bandcamp",
            ProviderId::LastFm => "Last.fm",
            ProviderId::Local => "Local",
        }
    }

    /// Every provider, including `Local`. Prefer the narrower lists
    /// ([`searchable`](ProviderId::searchable),
    /// [`defaultable`](ProviderId::defaultable),
    /// [`header_providers`](ProviderId::header_providers)) when only capable
    /// providers make sense.
    pub fn all() -> &'static [ProviderId] {
        &[
            ProviderId::YouTube,
            ProviderId::SoundCloud,
            ProviderId::MusicBrainz,
            ProviderId::Bandcamp,
            ProviderId::LastFm,
            ProviderId::Local,
        ]
    }

    /// All providers that appear in the search provider picker (excludes
    /// `Local`, which is not a remote search source).
    pub fn searchable() -> &'static [ProviderId] {
        &[
            ProviderId::YouTube,
            ProviderId::SoundCloud,
            ProviderId::MusicBrainz,
            ProviderId::Bandcamp,
            ProviderId::LastFm,
        ]
    }

    /// Providers eligible to be the default provider: must support both
    /// streaming and downloading (search-only `MusicBrainz`/`LastFm` and
    /// `Local` are excluded).
    pub fn defaultable() -> &'static [ProviderId] {
        &[
            ProviderId::YouTube,
            ProviderId::SoundCloud,
            ProviderId::Bandcamp,
        ]
    }

    /// Providers that can serve an artist-page header worth displaying
    /// (picture + stats + description). Shown in the artist header picker
    /// and pre-fetched as companions by `open_artist`. `MusicBrainz` is
    /// excluded: its header is stats-only with no picture.
    pub fn header_providers() -> &'static [ProviderId] {
        &[
            ProviderId::YouTube,
            ProviderId::SoundCloud,
            ProviderId::Bandcamp,
            ProviderId::LastFm,
        ]
    }

    pub fn capabilities(self) -> ProviderCaps {
        let a = crate::deps::availability();
        match self {
            ProviderId::YouTube => ProviderCaps {
                search: a.ytmusicapi || a.yt_dlp,
                stream: a.yt_dlp,
                download: a.yt_dlp,
                radio: a.ytmusicapi,
            },
            ProviderId::SoundCloud => ProviderCaps {
                // SoundCloud search is crate-based (no external tool); only
                // streaming/downloading route through yt-dlp.
                search: true,
                stream: a.yt_dlp,
                download: a.yt_dlp,
                radio: false,
            },
            ProviderId::MusicBrainz => ProviderCaps {
                search: true,
                stream: false,
                download: false,
                radio: false,
            },
            ProviderId::Bandcamp => ProviderCaps {
                search: true,
                stream: true,
                download: true,
                radio: false,
            },
            ProviderId::LastFm => ProviderCaps {
                search: true,
                stream: false,
                download: false,
                radio: true,
            },
            ProviderId::Local => ProviderCaps {
                search: false,
                stream: false,
                download: false,
                radio: false,
            },
        }
    }

    /// Scopes a search can be run against for this provider. `YouTube` exposes
    /// the full set; others are reduced to the track list plus whatever card
    /// browsing their API supports.
    pub fn supported_scopes(self) -> &'static [SearchScope] {
        match self {
            ProviderId::YouTube => SearchScope::all(),
            ProviderId::SoundCloud => &[
                SearchScope::Songs,
                SearchScope::Artists,
                SearchScope::Albums,
                SearchScope::Playlists,
            ],
            ProviderId::MusicBrainz | ProviderId::Bandcamp | ProviderId::LastFm => &[
                SearchScope::Songs,
                SearchScope::Artists,
                SearchScope::Albums,
            ],
            ProviderId::Local => &[SearchScope::Songs],
        }
    }

    /// The scopes that return playable tracks rather than cards, restricted to
    /// the ones this provider supports (`Songs` everywhere, `Videos` for
    /// `YouTube`). Picker for pick-one-result searches (the Edit Track popup's
    /// "Manual search"), where an artist/album/playlist scope would yield
    /// nothing selectable.
    pub fn track_scopes(self) -> Vec<SearchScope> {
        [SearchScope::Songs, SearchScope::Videos]
            .into_iter()
            .filter(|scope| self.supported_scopes().contains(scope))
            .collect()
    }

    /// Whether this provider streams/ downloads via yt-dlp (`YouTube`,
    /// `SoundCloud`) rather than a direct HTTP file URL.
    pub fn uses_ytdlp(self) -> bool {
        matches!(self, ProviderId::YouTube | ProviderId::SoundCloud)
    }

    /// The public web page for the artist this provider identifies by `id`.
    /// Providers whose artist ids *are* public addresses (channel ids, MBIDs,
    /// Last.fm artist names) resolve from the id alone; the rest only advertise
    /// a page on their cards, so a track carrying just the id has none.
    pub fn artist_page_url(self, id: &str) -> Option<String> {
        if id.is_empty() {
            return None;
        }
        match self {
            ProviderId::YouTube => Some(format!("https://music.youtube.com/channel/{id}")),
            ProviderId::MusicBrainz => Some(format!("https://musicbrainz.org/artist/{id}")),
            // Last.fm identifies artists by name, which is the last path
            // segment of their page.
            ProviderId::LastFm => Some(format!(
                "https://www.last.fm/music/{}",
                crate::util::urlencode(id)
            )),
            // SoundCloud and Bandcamp address artists by numeric user/band id;
            // `Local` has no artist at all.
            ProviderId::SoundCloud | ProviderId::Bandcamp | ProviderId::Local => None,
        }
    }

    /// The public web page for the album this provider identifies by `id` —
    /// the id a track carries in its `TrackAlbum`. Only providers whose album
    /// ids *are* public addresses resolve; the rest advertise a page on their
    /// cards alone. `MusicBrainz` tracks name a release group while its album
    /// cards name a release, so the two spellings differ.
    pub fn album_page_url(self, id: &str) -> Option<String> {
        if id.is_empty() {
            return None;
        }
        match self {
            // The same browse id the album cards carry, so a track's album page
            // and an album card's page are one address.
            ProviderId::YouTube => Some(format!("https://music.youtube.com/browse/{id}")),
            ProviderId::MusicBrainz => Some(format!("https://musicbrainz.org/release-group/{id}")),
            // SoundCloud and Bandcamp carry numeric ids; Last.fm tracks carry
            // no album at all.
            ProviderId::SoundCloud
            | ProviderId::Bandcamp
            | ProviderId::LastFm
            | ProviderId::Local => None,
        }
    }

    /// The public web page for one of this provider's tracks, when one can be
    /// derived from the data the provider handed us. `None` when the stored
    /// `url` is a media file or a local path and no page address is
    /// reconstructible from the id.
    pub fn track_page_url(self, pt: &ProviderTrack) -> Option<String> {
        match self {
            // These already store the page address: YouTube's watch page,
            // SoundCloud's permalink, Last.fm's track page.
            ProviderId::YouTube | ProviderId::SoundCloud | ProviderId::LastFm => {
                (!pt.url.is_empty()).then(|| pt.url.clone())
            }
            ProviderId::MusicBrainz => {
                (!pt.id.is_empty()).then(|| format!("https://musicbrainz.org/track/{}", pt.id))
            }
            // Bandcamp's `url` is a direct MP3 and its page slug is not
            // derivable from the numeric track id; `Local` has no web page.
            ProviderId::Bandcamp | ProviderId::Local => None,
        }
    }
}

/// A search scope: which kind of result a provider returns.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub enum SearchScope {
    #[default]
    Songs,
    Videos,
    Artists,
    Albums,
    Playlists,
}

impl SearchScope {
    pub fn all() -> &'static [SearchScope] {
        &[
            SearchScope::Songs,
            SearchScope::Videos,
            SearchScope::Artists,
            SearchScope::Albums,
            SearchScope::Playlists,
        ]
    }

    /// The `filter=` argument ytmusicapi expects for this scope (YouTube-only
    /// mapping; other providers ignore it).
    pub fn youtube_filter(self) -> &'static str {
        match self {
            SearchScope::Songs => "songs",
            SearchScope::Videos => "videos",
            SearchScope::Artists => "artists",
            SearchScope::Albums => "albums",
            SearchScope::Playlists => "playlists",
        }
    }
}

/// Provider-agnostic card result (artist/album/playlist drill-down). `url` is
/// the public page the provider advertised for the card, empty when it exposes
/// none (the card is then not offered "Open in browser").
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
pub struct CardData {
    pub id: String,
    pub title: String,
    pub subtitle: String,
    pub thumbnail: String,
    pub url: String,
}

/// Provider-agnostic search result: the playable tracks plus the active tab
/// describing which scopes produced card lists. Only `YouTube` currently
/// produces card tabs; other providers return a flat track list under
/// `SearchTab::Songs`.
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum SearchTab {
    #[default]
    Songs,
    Videos,
    Artists(Vec<CardData>),
    Albums(Vec<CardData>),
    Playlists(Vec<CardData>),
}

impl SearchTab {
    /// The tab for a search scope when no results have arrived yet.
    pub fn from_scope(scope: SearchScope) -> Self {
        match scope {
            SearchScope::Songs => SearchTab::Songs,
            SearchScope::Videos => SearchTab::Videos,
            SearchScope::Artists => SearchTab::Artists(Vec::new()),
            SearchScope::Albums => SearchTab::Albums(Vec::new()),
            SearchScope::Playlists => SearchTab::Playlists(Vec::new()),
        }
    }

    /// The search scope represented by this tab (inverse of [`from_scope`]).
    pub fn scope(&self) -> SearchScope {
        match self {
            SearchTab::Songs => SearchScope::Songs,
            SearchTab::Videos => SearchScope::Videos,
            SearchTab::Artists(_) => SearchScope::Artists,
            SearchTab::Albums(_) => SearchScope::Albums,
            SearchTab::Playlists(_) => SearchScope::Playlists,
        }
    }

    /// Whether this tab shows the playable track list (vs. card results).
    pub fn is_track_tab(&self) -> bool {
        matches!(self, SearchTab::Songs | SearchTab::Videos)
    }

    /// Number of card results shown by this tab (artists/albums/playlists).
    /// Returns `None` for the track tabs (`Songs`/`Videos`), whose result
    /// count lives in the sibling `Vec<Track>` returned alongside the tab.
    pub fn card_count(&self) -> Option<usize> {
        match self {
            SearchTab::Songs | SearchTab::Videos => None,
            SearchTab::Artists(items) | SearchTab::Albums(items) | SearchTab::Playlists(items) => {
                Some(items.len())
            }
        }
    }
}

/// Provider-scoped search entry point. Dispatches to the per-provider backend
/// and maps results into tracks carrying that provider's id.
pub fn search(
    provider: ProviderId,
    query: &str,
    scope: SearchScope,
    offset: usize,
) -> Result<(Vec<Track>, SearchTab)> {
    match provider {
        ProviderId::YouTube => youtube::search(query, scope, offset),
        ProviderId::SoundCloud => Ok(soundcloud::search(query, scope, offset)),
        ProviderId::MusicBrainz => Ok(musicbrainz::search(query, scope, offset)),
        ProviderId::Bandcamp => bandcamp::search(query, scope, offset),
        ProviderId::LastFm => lastfm::search(query, scope, offset),
        ProviderId::Local => Ok((Vec::new(), SearchTab::Songs)),
    }
}

/// Pagination for the active search, mirroring [`search`].
pub fn search_more(provider: ProviderId, query: &str, offset: usize) -> Result<Vec<Track>> {
    match provider {
        ProviderId::YouTube => youtube::search_more(query, offset),
        ProviderId::SoundCloud => Ok(soundcloud::search_more(query, offset)),
        ProviderId::MusicBrainz => Ok(musicbrainz::search_more(query, offset)),
        ProviderId::Bandcamp => bandcamp::search_more(query, offset),
        ProviderId::LastFm => lastfm::search_more(query, offset),
        ProviderId::Local => Ok(Vec::new()),
    }
}

/// Drill down into a card (artist/album/playlist) for `provider`. Returns the
/// browsed tracks; empty for providers that don't support browsing.
/// Album metadata shown in the album view header (type + release year).
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
pub struct AlbumMeta {
    pub badge: String,
    pub date: String,
    pub thumbnail: String,
}

pub fn browse(
    provider: ProviderId,
    id: &str,
    kind: &str,
) -> Result<(Vec<Track>, Option<AlbumMeta>)> {
    match provider {
        ProviderId::YouTube => youtube::browse(id, kind),
        ProviderId::SoundCloud => Ok((soundcloud::browse(id, kind)?, None)),
        ProviderId::MusicBrainz => Ok((musicbrainz::browse(id, kind)?, None)),
        ProviderId::Bandcamp => bandcamp::browse(id, kind),
        ProviderId::LastFm => lastfm::browse(id, kind),
        ProviderId::Local => Ok((Vec::new(), None)),
    }
}

pub use artist_page::{
    ArtistAlbumCard, ArtistDataKind, ArtistHeader, ArtistKindData, ArtistPage, ArtistPageState,
    ArtistSection, ArtistSectionKind, RelatedArtistCard, SectionContent,
};

/// One artist-page section fetch result: the kind and its data (or error).
/// See [`spawn_artist_kinds_fetch`].
pub struct ArtistKindResult(pub ArtistDataKind, pub Result<ArtistKindData, String>);

/// Fetch each requested kind of `provider`'s artist page on a background
/// thread, delivering one [`ArtistKindResult`] per kind as soon as its data
/// is available (via the returned channel). Providers that get everything in
/// one call (`YouTube`, `MusicBrainz`) send all kinds after that call;
/// `SoundCloud`'s independent endpoints deliver incrementally, so one
/// failing section no longer blanks the others.
pub fn spawn_artist_kinds_fetch(
    provider: ProviderId,
    id: &str,
    kinds: &'static [ArtistDataKind],
) -> std::sync::mpsc::Receiver<ArtistKindResult> {
    let (tx, rx) = std::sync::mpsc::channel();
    let id = id.to_string();
    thread::spawn(move || {
        if provider == ProviderId::SoundCloud {
            soundcloud::fetch_artist_kinds(&id, kinds, &tx);
        } else {
            // One-shot providers: a single request answers every kind; split
            // it into per-kind payloads and send them all at once. When
            // YouTube's popular tracks still lack durations/view counts, a
            // yt-dlp enrichment pass runs AFTER the fan-out (it takes
            // seconds) and resends Popular so the page never waits on it.
            let result = match provider {
                ProviderId::YouTube => youtube::fetch_artist_page(&id, kinds),
                ProviderId::MusicBrainz => musicbrainz::fetch_artist_page(&id, kinds),
                ProviderId::Bandcamp => bandcamp::fetch_artist_page(&id, kinds),
                ProviderId::LastFm => lastfm::fetch_artist_page(&id, kinds),
                _ => Ok(artist_page::ArtistPage::default()),
            }
            .map_err(|e| format!("{e:#}"));
            for &kind in kinds {
                let data = match &result {
                    Ok(page) => single_kind_data(page, kind)
                        .map_or_else(|| Err(format!("No {kind:?} data")), Ok),
                    Err(e) => Err(e.clone()),
                };
                let _ = tx.send(ArtistKindResult(kind, data));
            }
            if provider == ProviderId::YouTube {
                if let Ok(page) = &result {
                    if ArtistDataKind::Popular.wanted(kinds)
                        && youtube::needs_enrichment(&page.popular)
                    {
                        let mut page = page.clone();
                        youtube::enrich_track_metadata(&mut page.popular);
                        let _ = tx.send(ArtistKindResult(
                            ArtistDataKind::Popular,
                            Ok(ArtistKindData::Popular(page.popular)),
                        ));
                    }
                }
            }
        }
    });
    rx
}

/// Project `page` down to just `kind`'s data. `None` means the page has no
/// data for that kind (e.g. no header) — the kind is skipped rather than
/// cached as covered with empty content.
fn single_kind_data(page: &ArtistPage, kind: ArtistDataKind) -> Option<ArtistKindData> {
    use artist_page::ArtistKindData as D;
    match kind {
        ArtistDataKind::Header => page.header.clone().map(D::Header),
        ArtistDataKind::Popular => Some(D::Popular(page.popular.clone())),
        ArtistDataKind::Albums => Some(D::Albums(page.albums.clone())),
        ArtistDataKind::Playlists => Some(D::Playlists(page.playlists.clone())),
        ArtistDataKind::Related => Some(D::Related(page.related.clone())),
    }
}

/// Resolve an artist name to that provider's artist id (used to lazily open
/// a page section on a provider whose id isn't known yet). Returns
/// `Ok(None)` when no match was found.
pub fn resolve_artist_id(provider: ProviderId, name: &str) -> Result<Option<String>> {
    match provider {
        ProviderId::YouTube => youtube::resolve_artist_id(name),
        ProviderId::SoundCloud => soundcloud::resolve_artist_id(name),
        ProviderId::MusicBrainz => musicbrainz::resolve_artist_id(name),
        ProviderId::Bandcamp => bandcamp::resolve_artist_id(name),
        ProviderId::LastFm => lastfm::resolve_artist_id(name),
        ProviderId::Local => Ok(None),
    }
}

/// Build a song radio from a provider id (`YouTube` only supports similarity).
pub fn radio_song(provider: ProviderId, id: &str) -> Result<Vec<Track>> {
    match provider {
        ProviderId::YouTube => youtube::radio_song(id),
        ProviderId::LastFm => lastfm::radio_song(id),
        ProviderId::SoundCloud
        | ProviderId::MusicBrainz
        | ProviderId::Bandcamp
        | ProviderId::Local => Ok(Vec::new()),
    }
}

/// Build an artist radio from a provider browse id (`YouTube` only).
pub fn radio_artist(provider: ProviderId, id: &str) -> Result<Vec<Track>> {
    match provider {
        ProviderId::YouTube => youtube::radio_artist(id),
        ProviderId::LastFm => lastfm::radio_artist(id),
        ProviderId::SoundCloud
        | ProviderId::MusicBrainz
        | ProviderId::Bandcamp
        | ProviderId::Local => Ok(Vec::new()),
    }
}

/// Resolve a logical track (title/artist) to this provider's track by
/// searching. Returns the full resolved `Track` (carrying that provider's
/// id/url plus its duration/thumbnail/album) so the rich metadata survives
/// the resolution; returns `Ok(None)` if no match was found or the provider
/// cannot resolve (e.g. `Local`), and `Err` only on a genuine provider
/// failure. Drives the "play via / download from [provider]" flow.
pub fn resolve_id(provider: ProviderId, track: &Track) -> Result<Option<Track>> {
    match provider {
        ProviderId::YouTube => youtube::resolve_id(track),
        ProviderId::SoundCloud => soundcloud::resolve_id(track),
        ProviderId::MusicBrainz => musicbrainz::resolve_id(track),
        ProviderId::Bandcamp => bandcamp::resolve_id(track),
        ProviderId::LastFm => lastfm::resolve_id(track),
        ProviderId::Local => Ok(None),
    }
}

/// Progress events from the `YouTube` player-client race that precedes
/// streaming/downloading. Emitted on the caller's channel (`BackendResult`
/// for downloads, `PlayerState` for streams) and surfaced as toasts.
#[derive(Debug, Clone)]
pub enum ClientEvent {
    Resolving,
    Resolved(String),
    Unavailable,
}

/// Download a track's audio for `provider` into `download_dir`. The track must
/// already carry that provider's id/url. `emit` receives the player-client
/// race events (`YouTube` only; other providers ignore it).
pub fn download(
    provider: ProviderId,
    track: &Track,
    download_dir: &std::path::Path,
    emit: &dyn Fn(ClientEvent),
) -> Result<String> {
    match provider {
        ProviderId::YouTube => {
            let url = track
                .provider_url(provider)
                .unwrap_or_else(|| track.primary_url());
            youtube::download(url, download_dir, emit)
        }
        ProviderId::SoundCloud => soundcloud::download(track, download_dir),
        ProviderId::Bandcamp => bandcamp::download(track, download_dir),
        _ => anyhow::bail!("provider does not support downloading"),
    }
}

/// Per-provider identifier/url for a track. A single logical track may carry
/// several of these (one per provider that has resolved it). Provider-specific
/// display metadata (`duration`/`thumbnail`/`album`) lives here so each
/// provider's view of a track is self-contained.
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProviderTrack {
    pub id: String,
    /// For remote providers, the streamable/playable URL. For the `Local`
    /// provider this is the on-disk path of the imported/downloaded audio
    /// file (a local file has no remote URL).
    pub url: String,
    pub artist_id: Option<String>,
    pub duration: u32,
    pub thumbnail: String,
    pub album: Option<crate::types::TrackAlbum>,
    #[serde(default)]
    pub play_count: u64,
}

/// Map of provider id -> that provider's identifier/url for a track.
pub type ProviderMap = HashMap<ProviderId, ProviderTrack>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn album_pages_resolve_only_where_the_id_is_a_public_address() {
        // The browse id a YouTube track carries is the same one its album
        // cards carry, so both resolve to one address.
        assert_eq!(
            ProviderId::YouTube.album_page_url("MPREb_abc"),
            Some("https://music.youtube.com/browse/MPREb_abc".into())
        );
        // MusicBrainz tracks carry the release group, not the release.
        assert_eq!(
            ProviderId::MusicBrainz.album_page_url("rg-1"),
            Some("https://musicbrainz.org/release-group/rg-1".into())
        );
        for p in [
            ProviderId::SoundCloud,
            ProviderId::Bandcamp,
            ProviderId::LastFm,
            ProviderId::Local,
        ] {
            assert_eq!(p.album_page_url("12345"), None, "{p:?}");
        }
        assert_eq!(ProviderId::YouTube.album_page_url(""), None);
    }

    #[test]
    fn artist_pages_resolve_only_where_the_id_is_a_public_address() {
        assert_eq!(
            ProviderId::YouTube.artist_page_url("UCabc"),
            Some("https://music.youtube.com/channel/UCabc".into())
        );
        assert_eq!(
            ProviderId::MusicBrainz.artist_page_url("mbid-1"),
            Some("https://musicbrainz.org/artist/mbid-1".into())
        );
        // Last.fm identifies artists by name, so the id needs encoding.
        assert_eq!(
            ProviderId::LastFm.artist_page_url("Sigur Rós"),
            Some("https://www.last.fm/music/Sigur+R%C3%B3s".into())
        );
        // Numeric user/band ids address nothing on the web.
        assert_eq!(ProviderId::SoundCloud.artist_page_url("12345"), None);
        assert_eq!(ProviderId::Bandcamp.artist_page_url("12345"), None);
        assert_eq!(ProviderId::Local.artist_page_url("12345"), None);
        assert_eq!(ProviderId::YouTube.artist_page_url(""), None);
    }
}
