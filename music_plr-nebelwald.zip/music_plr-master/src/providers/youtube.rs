use std::{process::Command, time::Duration};

use anyhow::{Context, Result};
use serde::Deserialize;

use super::{run_command_with_stdin_and_timeout, run_command_with_timeout, ytdlp};
use crate::{
    providers::{
        ArtistAlbumCard, ArtistHeader, CardData, ProviderId, RelatedArtistCard, SearchScope,
        SearchTab,
    },
    types::Track,
};

#[derive(Debug, Clone, serde::Deserialize)]
pub struct YouTubeVideo {
    pub id: String,
    pub title: String,
    pub url: String,
    #[serde(default, deserialize_with = "deserialize_flexible_duration")]
    pub duration: u32,
    #[serde(default)]
    pub channel: String,
    #[serde(default)]
    pub thumbnail: String,
    #[serde(default)]
    pub album: Option<crate::types::TrackAlbum>,
    #[serde(default)]
    pub artist_id: Option<String>,
    /// ytmusicapi's abbreviated view count ("1.2M", "841M plays"), parsed
    /// to an exact number at deserialization; 0 when absent.
    #[serde(default, deserialize_with = "deserialize_view_count")]
    pub views: u64,
}

impl From<YouTubeVideo> for Track {
    fn from(v: YouTubeVideo) -> Self {
        Track::from_provider_with_count(
            ProviderId::YouTube,
            v.id,
            v.url,
            v.title,
            v.channel,
            v.duration,
            v.thumbnail,
            v.album,
            v.artist_id,
            v.views,
        )
    }
}

#[derive(Deserialize)]
struct YTDLPSearchResult {
    id: String,
    title: String,
    #[serde(default, deserialize_with = "deserialize_flexible_duration")]
    duration: u32,
    channel: String,
    #[serde(default)]
    webpage_url: String,
    #[serde(default)]
    view_count: Option<u64>,
}

/// Durations beyond a week are garbage (e.g. "1e30"), not tracks.
const MAX_TRACK_SECS: f64 = 7.0 * 24.0 * 3600.0;

/// Accept either an abbreviated string ("1.2M", "841M plays") or a plain
/// number for view counts.
fn deserialize_view_count<'de, D>(deserializer: D) -> Result<u64, D::Error>
where
    D: serde::Deserializer<'de>,
{
    use serde_json::Value;
    Ok(match Value::deserialize(deserializer)? {
        Value::Number(n) => n.as_u64().unwrap_or(0),
        Value::String(s) => parse_abbreviated_count(&s),
        _ => 0,
    })
}

/// ytmusicapi emits durations either as seconds (search) or as a raw
/// "M:SS"/"H:MM:SS" string (browse/watch shelves); accept both.
fn deserialize_flexible_duration<'de, D>(deserializer: D) -> Result<u32, D::Error>
where
    D: serde::Deserializer<'de>,
{
    use serde_json::Value;
    let secs = match Value::deserialize(deserializer)? {
        Value::Number(n) => n.as_f64().unwrap_or(0.0),
        Value::String(s) => s
            .split(':')
            .try_fold(0.0_f64, |acc, part| {
                part.trim().parse::<f64>().map(|p| acc * 60.0 + p)
            })
            .unwrap_or(0.0),
        _ => 0.0,
    };
    let secs = if secs.is_finite() && (0.0..MAX_TRACK_SECS).contains(&secs) {
        secs
    } else {
        0.0
    };
    Ok(secs as u32)
}

/// Parse ytmusicapi's view/play counts ("1.2M", "847", "3.4K", "841M plays").
fn parse_abbreviated_count(s: &str) -> u64 {
    let s = s
        .trim()
        .trim_end_matches("plays")
        .trim_end_matches("views")
        .trim()
        .replace(['\u{a0}', ','], "");
    let (num, mult) = match s.chars().last() {
        Some('K' | 'k') => (&s[..s.len() - 1], 1_000u64),
        Some('M' | 'm') => (&s[..s.len() - 1], 1_000_000),
        Some('B' | 'b') => (&s[..s.len() - 1], 1_000_000_000),
        _ => (s.as_str(), 1),
    };
    num.parse::<f64>().map_or(0, |n| (n * mult as f64) as u64)
}

const SEARCH_TIMEOUT: Duration = Duration::from_mins(1);
const PYTHON_TIMEOUT: Duration = Duration::from_secs(30);

fn cached_script_path() -> std::path::PathBuf {
    static PATH: std::sync::OnceLock<std::path::PathBuf> = std::sync::OnceLock::new();
    PATH.get_or_init(|| {
        let path =
            std::env::temp_dir().join(format!("goosemusic_search_{}.py", std::process::id()));
        let _ = std::fs::write(&path, include_str!("../youtube_search.py"));
        path
    })
    .clone()
}

/// Run the embedded ytmusicapi script (written once per process) with the first
/// candidate Python that has `ytmusicapi` (app venv, standalone, system).
fn run_python(mode: &str, args: &[&str]) -> Result<String> {
    let script_path = cached_script_path();

    let candidates = crate::deps::candidate_pythons();
    if candidates.is_empty() {
        anyhow::bail!("Python 3 not found; install it to search YouTube Music.");
    }
    let mut last_stderr = String::new();
    for py in &candidates {
        let output = run_python_with(py, &script_path, mode, args)?;
        if output.status.success() {
            return Ok(String::from_utf8_lossy(&output.stdout).into_owned());
        }
        let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
        if is_import_error(&stderr) {
            last_stderr = stderr;
            continue;
        }
        anyhow::bail!("ytmusicapi {mode} failed: {stderr}");
    }
    anyhow::bail!("ytmusicapi {mode} failed: {last_stderr}");
}

fn run_python_with(
    py: &std::path::Path,
    script: &std::path::Path,
    mode: &str,
    args: &[&str],
) -> Result<std::process::Output> {
    let mut cmd = Command::new(py);
    cmd.arg(script).arg(mode).args(args);
    run_command_with_timeout(&mut cmd, PYTHON_TIMEOUT)
        .context("Failed to run Python. Is it installed?")
}

fn is_import_error(stderr: &str) -> bool {
    stderr.contains("ModuleNotFoundError")
        || stderr.contains("ImportError")
        || stderr.contains("No module named")
}

/// Run a search and split the result into the playable `Track` list (for
/// Songs/Videos) and the `SearchTab` describing which tab is active (carrying
/// the concrete card lists for Artists/Albums/Playlists). yt-dlp is the
/// fallback for pagination (`search_more`) and when ytmusicapi is unavailable;
/// it only yields playable tracks, so the scoped card tabs rely on ytmusicapi.
pub fn search(query: &str, scope: SearchScope, offset: usize) -> Result<(Vec<Track>, SearchTab)> {
    if offset == 0 {
        if let Ok(parts) = search_ytmusic(query, scope) {
            return Ok(parts);
        }
    }
    let videos = search_ytdlp(query, offset, crate::theme::SEARCH_PAGE_SIZE)?;
    let tracks: Vec<Track> = videos.into_iter().map(Track::from).collect();
    Ok((tracks, SearchTab::Songs))
}

/// Browse the contents of an artist/album/playlist, returning its tracks.
/// Album browse payload: the python helper returns `{meta, tracks}` for
/// albums; other kinds (and older helpers) return a bare track list.
#[derive(Deserialize)]
#[serde(untagged)]
enum YtBrowseOutput {
    Album {
        #[serde(default)]
        meta: crate::providers::AlbumMeta,
        #[serde(default)]
        tracks: Vec<YouTubeVideo>,
    },
    Tracks(Vec<YouTubeVideo>),
}

pub fn browse(id: &str, kind: &str) -> Result<(Vec<Track>, Option<crate::providers::AlbumMeta>)> {
    let stdout = run_python("browse", &[id, "50", kind])?;
    match serde_json::from_str::<YtBrowseOutput>(&stdout)
        .context("Failed to parse ytmusicapi browse output")?
    {
        YtBrowseOutput::Album { meta, tracks } => {
            let has_meta = !meta.badge.is_empty() || !meta.date.is_empty();
            let out = if has_meta { Some(meta) } else { None };
            Ok((tracks.into_iter().map(Track::from).collect(), out))
        }
        YtBrowseOutput::Tracks(items) => Ok((items.into_iter().map(Track::from).collect(), None)),
    }
}

/// Raw JSON shape returned by the python helper's `artist_page` mode. The
/// card lists deserialize straight into the shared provider types.
#[derive(Deserialize, Default)]
#[serde(default)]
struct YtArtistPageRaw {
    header: ArtistHeader,
    popular: Vec<YouTubeVideo>,
    albums: Vec<ArtistAlbumCard>,
    playlists: Vec<CardData>,
    related: Vec<RelatedArtistCard>,
}

/// Fetch the full artist page (header, popular songs, album/single/playlist
/// shelves, related artists) via the python helper.
pub fn fetch_artist_page(
    id: &str,
    kinds: &[crate::providers::ArtistDataKind],
) -> Result<crate::providers::ArtistPage> {
    use crate::providers::{ArtistDataKind as K, ArtistPage};

    // YouTube serves the whole page in a single request regardless of which
    // kinds are asked; unrequested kinds are filtered out of the result.
    let stdout = run_python("artist_page", &[id])?;
    let mut raw: YtArtistPageRaw =
        serde_json::from_str(&stdout).context("Failed to parse ytmusicapi artist_page output")?;
    // The songs shelf carries neither durations nor (parsed) view counts;
    // the python helper backfills both (plays from the raw shelf, durations
    // from the shelf's backing playlist). [`enrich_track_metadata`] stays as
    // a yt-dlp fallback for anything still missing.
    if !K::Popular.wanted(kinds) {
        raw.popular.clear();
    }
    if !K::Header.wanted(kinds) {
        raw.header.stats.clear();
        raw.header.description.clear();
        raw.header.image.clear();
    }
    if !K::Albums.wanted(kinds) {
        raw.albums.clear();
    }
    if !K::Playlists.wanted(kinds) {
        raw.playlists.clear();
    }
    if !K::Related.wanted(kinds) {
        raw.related.clear();
    }
    // The helper reports bare ids for the shelves too; their pages are the same
    // templates the search path uses.
    for card in &mut raw.albums {
        card.url = album_page_url(&card.id);
    }
    for card in &mut raw.playlists {
        card.url = playlist_page_url(&card.id);
    }
    for card in &mut raw.related {
        card.url = artist_page_url(&card.id);
    }
    Ok(ArtistPage {
        header: Some(raw.header),
        popular: raw.popular.into_iter().map(Track::from).collect(),
        albums: raw.albums,
        playlists: raw.playlists,
        related: raw.related,
    })
}

/// Resolve an artist name to a `YouTube` channel browseId via the Artists
/// search scope. Returns `Ok(None)` when nothing matched.
pub fn resolve_artist_id(name: &str) -> Result<Option<String>> {
    let (_, tab) = search_ytmusic(name, SearchScope::Artists)?;
    Ok(match tab {
        SearchTab::Artists(cards) => cards.into_iter().next().map(|c| c.id),
        _ => None,
    })
}

/// Public page for a `YouTube` Music artist/album/playlist. Card ids are
/// already addressable (channel ids, album browse ids, playlist ids), so the
/// page is a template over the id rather than something the helper has to
/// report. These mirror the shapes the helper itself prints for song results.
fn artist_page_url(id: &str) -> String {
    // The shared rule for "artist page for this id" lives on the provider, so
    // a track's artist id resolves to the same page its cards do.
    ProviderId::YouTube.artist_page_url(id).unwrap_or_default()
}

fn album_page_url(id: &str) -> String {
    // Same id space as the ids on tracks' `TrackAlbum`, so both go through the
    // shared rule.
    ProviderId::YouTube.album_page_url(id).unwrap_or_default()
}

fn playlist_page_url(id: &str) -> String {
    // Playlist browse ids may carry a `VL` prefix the web page doesn't take.
    let id = id.strip_prefix("VL").unwrap_or(id);
    format!("https://music.youtube.com/playlist?list={id}")
}

fn search_ytmusic(query: &str, scope: SearchScope) -> Result<(Vec<Track>, SearchTab)> {
    let limit = 20;
    let limit_str = limit.to_string();
    let scope_arg = scope.youtube_filter();
    let stdout = run_python("search", &[query, scope_arg, &limit_str])?;

    let raw: Vec<serde_json::Value> =
        serde_json::from_str(&stdout).context("Failed to parse ytmusicapi output")?;

    let mut tracks: Vec<Track> = Vec::new();
    let mut cards: Vec<CardData> = Vec::new();
    let mut albums: Vec<CardData> = Vec::new();
    let mut playlists: Vec<CardData> = Vec::new();
    for v in raw {
        let kind = v.get("kind").and_then(|k| k.as_str()).unwrap_or("track");
        let id = v["id"].as_str().unwrap_or_default().to_string();
        let title = v["title"].as_str().unwrap_or_default().to_string();
        let subtitle = v["subtitle"].as_str().unwrap_or_default().to_string();
        let thumbnail = v["thumbnail"].as_str().unwrap_or_default().to_string();
        match kind {
            "artist" => cards.push(CardData {
                url: artist_page_url(&id),
                id,
                title,
                subtitle: String::new(),
                thumbnail,
            }),
            "album" => albums.push(CardData {
                url: album_page_url(&id),
                id,
                title,
                subtitle,
                thumbnail,
            }),
            "playlist" => playlists.push(CardData {
                url: playlist_page_url(&id),
                id,
                title,
                subtitle,
                thumbnail,
            }),
            _ => {
                // song / video -> YouTubeVideo
                if let Ok(video) = serde_json::from_value::<YouTubeVideo>(v) {
                    tracks.push(video.into());
                }
            }
        }
    }

    let tab = match scope {
        SearchScope::Songs => SearchTab::Songs,
        SearchScope::Videos => SearchTab::Videos,
        SearchScope::Artists => SearchTab::Artists(cards),
        SearchScope::Albums => SearchTab::Albums(albums),
        SearchScope::Playlists => SearchTab::Playlists(playlists),
    };
    Ok((tracks, tab))
}

fn search_ytdlp(query: &str, offset: usize, page_size: usize) -> Result<Vec<YouTubeVideo>> {
    // yt-dlp cannot parse an empty/blank query ("ytsearchN:" alone is an
    // unsupported url scheme); blank queries are served by the ytmusicapi
    // charts path, so degrade to an empty page instead of erroring.
    if query.trim().is_empty() {
        return Ok(Vec::new());
    }
    // flat_search returns full metadata in a single yt-dlp pass.
    let (videos, _) = flat_search(query, offset + 1, offset + page_size)?;
    Ok(videos)
}

pub fn search_more(query: &str, offset: usize) -> Result<Vec<Track>> {
    // Pagination only works through yt-dlp, which yields playable tracks.
    // (Scoped non-All searches get their first page from ytmusicapi; further
    // pages fall back to general track results — acceptable for "Load More".)
    let videos = search_ytdlp(query, offset, crate::theme::SEARCH_PAGE_SIZE)?;
    Ok(videos.into_iter().map(Track::from).collect())
}

// yt-dlp search pass. The `ytsearchN:` prefix requests up to N results;
// `--playlist-start/--playlist-end` then slice the requested window. (The old
// `--default-search <music-url> --flat-playlist` combo now resolves to channel
// browse ids — `UC...` — which is_video_id() rejects, so every search returned
// zero results.) Each dumped entry already carries duration/channel/views, so
// no second metadata pass is required. Playlist offsets are 1-based per
// yt-dlp's --playlist-start/--playlist-end convention; callers must convert
// 0-based offsets to 1-based before calling.
fn flat_search(query: &str, start: usize, end: usize) -> Result<(Vec<YouTubeVideo>, Vec<String>)> {
    let start_str = start.to_string();
    let end_str = end.to_string();
    // `ytsearchN:` caps how many results yt-dlp fetches; use `end` (the upper
    // bound of the requested window) as N so the slice below is always within
    // what was actually fetched.
    let search_spec = format!("ytsearch{end}:{query}");
    let args: Vec<&str> = vec![
        "--dump-json",
        "--no-warnings",
        "--skip-download",
        "--playlist-start",
        &start_str,
        "--playlist-end",
        &end_str,
        &search_spec,
    ];

    let mut cmd =
        crate::deps::yt_dlp_command().context("Failed to run yt-dlp. Is it installed?")?;
    cmd.args(&args);
    let flat_output = run_command_with_timeout(&mut cmd, SEARCH_TIMEOUT)
        .context("Failed to run yt-dlp. Is it installed?")?;

    if !flat_output.status.success() {
        let stderr = String::from_utf8_lossy(&flat_output.stderr);
        anyhow::bail!("yt-dlp search failed: {stderr}");
    }

    let mut videos: Vec<YouTubeVideo> = Vec::new();
    let mut valid_ids: Vec<String> = Vec::new();

    for line in String::from_utf8_lossy(&flat_output.stdout).lines() {
        if line.trim().is_empty() {
            continue;
        }
        if let Ok(item) = serde_json::from_str::<YTDLPSearchResult>(line) {
            let id = item.id;
            // Skip non-video playlist entries (mixes, channels, etc.).
            if !is_video_id(&id) {
                continue;
            }
            valid_ids.push(id.clone());
            videos.push(YouTubeVideo {
                id: id.clone(),
                title: item.title,
                url: if item.webpage_url.is_empty() {
                    format!("https://youtube.com/watch?v={id}")
                } else {
                    item.webpage_url
                },
                duration: item.duration,
                channel: item.channel,
                thumbnail: format!("https://i.ytimg.com/vi/{id}/mqdefault.jpg"),
                album: None,
                views: item.view_count.unwrap_or(0),
                artist_id: None,
            });
        }
    }

    Ok((videos, valid_ids))
}

/// Whether any track still lacks duration or play-count data, i.e. the
/// yt-dlp [`enrich_track_metadata`] pass would have work to do. The python
/// helper now backfills both for artist shelves, so a fully populated page
/// skips the slow subprocess entirely.
pub fn needs_enrichment(tracks: &[crate::types::Track]) -> bool {
    tracks.iter().any(|t| {
        t.providers
            .get(&ProviderId::YouTube)
            .is_some_and(|pt| pt.duration == 0 || pt.play_count == 0)
    })
}

/// Fill missing duration/view-count data on YouTube-sourced tracks with one
/// batched yt-dlp metadata pass. Used as a second phase after the artist
/// page renders, so popular rows don't wait on yt-dlp. Only tracks that are
/// actually missing data are queried.
pub fn enrich_track_metadata(tracks: &mut [crate::types::Track]) {
    let ids: Vec<String> = tracks
        .iter()
        .filter(|t| {
            t.providers
                .get(&ProviderId::YouTube)
                .is_some_and(|pt| pt.duration == 0 || pt.play_count == 0)
        })
        .filter_map(|t| t.provider_id(ProviderId::YouTube).map(str::to_string))
        .collect();
    if ids.is_empty() {
        return;
    }
    let metadata = fetch_batch_metadata(&ids);
    for track in tracks.iter_mut() {
        let Some(id) = track.provider_id(ProviderId::YouTube).map(str::to_string) else {
            continue;
        };
        if let (Some(item), Some(pt)) = (
            metadata.get(&id),
            track.providers.get_mut(&ProviderId::YouTube),
        ) {
            if pt.duration == 0 {
                pt.duration = item.duration;
            }
            // The yt-dlp pass's exact view_count is the fallback for rows
            // the shelf couldn't supply counts for.
            if pt.play_count == 0 {
                pt.play_count = item.view_count.unwrap_or(0);
            }
        }
    }
}

// Single batched metadata pass over yt-dlp for a list of video ids. Returns a
// map keyed by video id; a failed yt-dlp invocation yields an empty map so
// callers gracefully fall back to the cheap flat-search stubs.
fn fetch_batch_metadata(
    valid_ids: &[String],
) -> std::collections::HashMap<String, YTDLPSearchResult> {
    use std::collections::HashMap;
    let mut results: HashMap<String, YTDLPSearchResult> = HashMap::new();

    let Some(path) = crate::deps::resolve_yt_dlp() else {
        return results;
    };
    let cookie_args = crate::deps::cookie_args();
    let mut batch_args = vec![
        "--batch-file",
        "-",
        "--dump-json",
        "--skip-download",
        "--no-warnings",
    ];
    batch_args.extend(cookie_args.iter().map(String::as_str));
    let mut cmd = Command::new(path);
    cmd.args(&batch_args);
    // `--batch-file -` reads the URLs from stdin, one per line.
    let mut stdin = Vec::new();
    for id in valid_ids {
        stdin.extend_from_slice(format!("https://youtube.com/watch?v={id}\n").as_bytes());
    }
    let Ok(output) =
        run_command_with_stdin_and_timeout(&mut cmd, Some(stdin), Duration::from_mins(1))
    else {
        return results;
    };
    if output.status.success() {
        for line in String::from_utf8_lossy(&output.stdout).lines() {
            if line.trim().is_empty() {
                continue;
            }
            if let Ok(item) = serde_json::from_str::<YTDLPSearchResult>(line) {
                results.insert(item.id.clone(), item);
            }
        }
    }
    results
}

/// Fetch a `YouTube` Music radio/mix playlist via ytmusicapi's watch-playlist
/// engine (the same one behind the site's "Start radio" button). Pass a
/// `video_id` for a song-seeded mix or a `playlist_id` (e.g. an artist
/// browseId) for an artist/playlist mix. Durations and thumbnails are derived
/// locally from the watch-playlist response, so no extra yt-dlp pass is
/// needed (which keeps radio generation to a couple of seconds).
pub fn watch_playlist(video_id: Option<&str>, playlist_id: Option<&str>) -> Result<Vec<Track>> {
    let video_arg = video_id.unwrap_or("");
    let playlist_arg = playlist_id.unwrap_or("");
    let stdout = run_python("watch", &[video_arg, playlist_arg, "50"])?;
    let items: Vec<YouTubeVideo> =
        serde_json::from_str(&stdout).context("Failed to parse ytmusicapi watch output")?;
    Ok(items.into_iter().map(Track::from).collect())
}

/// Build a song radio from a real `YouTube` Music mix seeded by the track's
/// `video_id`.
pub fn radio_song(video_id: &str) -> Result<Vec<Track>> {
    watch_playlist(Some(video_id), None)
}

/// Build an artist radio from a real `YouTube` Music mix seeded by the artist's
/// `browse_id` (resolved from the track's provider artist id).
pub fn radio_artist(browse_id: &str) -> Result<Vec<Track>> {
    watch_playlist(None, Some(browse_id))
}

/// Resolve a logical track (title + artist) to a `YouTube` video id by running a
/// yt-dlp search and returning the first result's id. Used by the "play via /
/// download from `YouTube`" flow when a track lacks a `YouTube` id.
pub fn resolve_id(track: &Track) -> Result<Option<Track>> {
    let query = track.search_query();
    let (videos, _) = flat_search(&query, 1, 1)?;
    Ok(videos.into_iter().next().map(|mut v| {
        if v.url.is_empty() {
            v.url = format!("https://www.youtube.com/watch?v={}", v.id);
        }
        Track::from(v)
    }))
}

pub fn download(
    video_url: &str,
    download_dir: &std::path::Path,
    emit: &dyn Fn(crate::providers::ClientEvent),
) -> Result<String> {
    let id = video_url
        .split("v=")
        .nth(1)
        .and_then(|s| s.split('&').next())
        .unwrap_or("download");
    let output_path = super::download_file_path(download_dir, id);
    download_audio(video_url, output_path.to_string_lossy().as_ref(), emit)
}

pub fn download_audio(
    video_url: &str,
    output_path: &str,
    emit: &dyn Fn(crate::providers::ClientEvent),
) -> Result<String> {
    // Start on yt-dlp's defaults (best quality for most videos); the
    // quality-aware race runs only if this attempt fails with a client
    // failure. Never start on the remembered winner: it was the best client
    // for a *different* video and may only offer a low-bitrate muxed MP4 here
    // while defaults serve high-bitrate audio.
    match ytdlp::download_audio(video_url, output_path, &[]) {
        Ok(path) => Ok(path),
        Err(e) if ytdlp::is_youtube_url(video_url) && ytdlp::is_client_failure(&e.to_string()) => {
            ytdlp::forget_client();
            let (winner, _) = ytdlp::resolve_player_client(video_url, ytdlp::DOWNLOAD_FORMAT, emit);
            let extractor_arg = winner
                .as_deref()
                .map(|c| format!("youtube:player_client={c}"));
            let extra_args: Vec<&str> = match &extractor_arg {
                Some(arg) => vec!["--extractor-args", arg.as_str()],
                None => Vec::new(),
            };
            match ytdlp::download_audio(video_url, output_path, &extra_args) {
                Ok(path) => Ok(path),
                Err(e) => {
                    if ytdlp::is_client_failure(&e.to_string()) {
                        ytdlp::forget_client();
                    }
                    Err(e)
                }
            }
        }
        Err(e) => {
            if ytdlp::is_client_failure(&e.to_string()) {
                ytdlp::forget_client();
            }
            Err(e)
        }
    }
}

/// Whether `id` looks like a real `YouTube` video `id` (11 chars, not a
/// mix/playlist/channel entry). yt-dlp's flat playlist also returns mixes
/// (`MPRE` prefix), channel uploads (`UC` prefix), and other non-video
/// entries whose ids are longer than the 11-character video id; those are
/// filtered out so the search results stay playable.
fn is_video_id(id: &str) -> bool {
    id.len() == 11 && !id.starts_with("MPRE") && !id.starts_with("UC")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn needs_enrichment_only_when_data_missing() {
        use crate::types::Track;
        fn track(id: &str, duration: u32, plays: u64) -> Track {
            Track::from_provider_with_count(
                ProviderId::YouTube,
                id.into(),
                "url".into(),
                "t",
                "a",
                duration,
                "thumb",
                None,
                None,
                plays,
            )
        }
        assert!(!needs_enrichment(&[]));
        assert!(!needs_enrichment(&[track("a", 259, 100)]));
        assert!(!needs_enrichment(&[
            track("a", 259, 100),
            track("b", 300, 50)
        ]));
        assert!(needs_enrichment(&[track("a", 0, 100)]));
        assert!(needs_enrichment(&[track("a", 259, 0)]));
        assert!(needs_enrichment(&[track("a", 259, 100), track("b", 0, 0)]));
    }

    #[test]
    fn deserializes_view_count_shapes() {
        let v: YouTubeVideo = serde_json::from_value(serde_json::json!({
            "id": "a", "title": "t", "url": "u", "views": "841M plays"
        }))
        .unwrap();
        assert_eq!(v.views, 841_000_000);
        let v: YouTubeVideo = serde_json::from_value(serde_json::json!({
            "id": "a", "title": "t", "url": "u", "views": null
        }))
        .unwrap();
        assert_eq!(v.views, 0);
        let v: YouTubeVideo = serde_json::from_value(serde_json::json!({
            "id": "a", "title": "t", "url": "u", "views": 841_234
        }))
        .unwrap();
        assert_eq!(v.views, 841_234);
        for fractional in [-12.5f64, 841_234.7, u64::MAX as f64 * 2.0] {
            let v: YouTubeVideo = serde_json::from_value(serde_json::json!({
                "id": "a", "title": "t", "url": "u", "views": fractional
            }))
            .unwrap();
            assert_eq!(v.views, 0, "non-u64 number {fractional} degrades to 0");
        }
    }

    #[test]
    fn deserializes_mixed_duration_shapes() {
        let v: YouTubeVideo = serde_json::from_value(serde_json::json!({
            "id": "a", "title": "t", "url": "u",
            "duration": "4:36"
        }))
        .unwrap();
        assert_eq!(v.duration, 276);
        let v: YouTubeVideo = serde_json::from_value(serde_json::json!({
            "id": "a", "title": "t", "url": "u", "duration": 321.0
        }))
        .unwrap();
        assert_eq!(v.duration, 321);
        let v: YouTubeVideo = serde_json::from_value(serde_json::json!({
            "id": "a", "title": "t", "url": "u", "duration": null
        }))
        .unwrap();
        assert_eq!(v.duration, 0);
        for malformed in ["-1:30", "1e30", "4:xx"] {
            let v: YouTubeVideo = serde_json::from_value(serde_json::json!({
                "id": "a", "title": "t", "url": "u", "duration": malformed
            }))
            .unwrap();
            assert_eq!(v.duration, 0, "malformed duration {malformed} -> 0");
        }
        let v: YouTubeVideo = serde_json::from_value(serde_json::json!({
            "id": "a", "title": "t", "url": "u", "duration": 1e30
        }))
        .unwrap();
        assert_eq!(v.duration, 0);
        let v: YouTubeVideo = serde_json::from_value(serde_json::json!({
            "id": "a", "title": "t", "url": "u", "duration": "2:00:05"
        }))
        .unwrap();
        assert_eq!(v.duration, 7205);
    }
    use super::parse_abbreviated_count as p;

    #[test]
    fn parses_abbreviated_counts() {
        assert_eq!(p("847"), 847);
        assert_eq!(p("1.2K"), 1_200);
        assert_eq!(p("966K"), 966_000);
        assert_eq!(p("4.9M"), 4_900_000);
        assert_eq!(p("841M plays"), 841_000_000);
        assert_eq!(p("614M\u{a0}plays"), 614_000_000);
        assert_eq!(p("3.4B views"), 3_400_000_000);
        assert_eq!(p(""), 0);
        assert_eq!(p("garbage"), 0);
        assert_eq!(p(" \u{a0}1.2K "), 1_200);
        assert_eq!(p("-3K"), 0);
    }
}
