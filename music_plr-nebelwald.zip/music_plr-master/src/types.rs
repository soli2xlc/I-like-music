#[cfg(test)]
use std::collections::HashMap;
use std::collections::VecDeque;

use serde::{Deserialize, Serialize};

/// Per-provider identifier/url for a track. Re-exported from the provider
/// module for convenience.
pub use crate::providers::ProviderTrack;
use crate::providers::{ProviderId, ProviderMap};

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct TrackAlbum {
    pub name: String,
    pub id: String,
}

#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
pub struct Track {
    pub title: String,
    pub artist: String,
    pub source: ProviderId,
    pub providers: ProviderMap,
}

impl Track {
    /// Source-provider metadata, used for display. Falls back to the first
    /// carrier when the source entry is missing (e.g. a `Local` track).
    fn source_provider(&self) -> Option<&ProviderTrack> {
        if let Some(pt) = self.providers.get(&self.source) {
            return Some(pt);
        }
        self.providers.values().next()
    }

    fn source_or_any<'a, T>(&'a self, f: impl Fn(&'a ProviderTrack) -> Option<T>) -> Option<T> {
        self.source_provider()
            .and_then(&f)
            .or_else(|| self.providers.values().find_map(f))
    }

    /// The track duration in seconds, taken from the source provider's data.
    pub fn duration(&self) -> u32 {
        self.source_or_any(|p| (p.duration > 0).then_some(p.duration))
            .unwrap_or(0)
    }

    /// The thumbnail URL, taken from the source provider's data.
    pub fn thumbnail(&self) -> &str {
        self.source_or_any(|p| (!p.thumbnail.is_empty()).then_some(p.thumbnail.as_str()))
            .unwrap_or("")
    }

    /// The play count, taken from the source provider's data when nonzero,
    /// falling back to any carrier that reports one.
    pub fn play_count(&self) -> u64 {
        self.source_provider().map_or(0, |p| p.play_count).max(
            self.providers
                .values()
                .map(|p| p.play_count)
                .max()
                .unwrap_or(0),
        )
    }

    /// The album metadata, taken from the source provider's data.
    pub fn album(&self) -> Option<&TrackAlbum> {
        self.source_or_any(|p| p.album.as_ref())
    }
}

impl Track {
    /// The provider id for `provider`, if known.
    pub fn provider_id(&self, provider: ProviderId) -> Option<&str> {
        self.providers.get(&provider).map(|t| t.id.as_str())
    }

    /// The provider URL for `provider`, if known.
    pub fn provider_url(&self, provider: ProviderId) -> Option<&str> {
        self.providers.get(&provider).map(|t| t.url.as_str())
    }

    /// The provider artist id for `provider`, if known.
    pub fn provider_artist_id(&self, provider: ProviderId) -> Option<&str> {
        self.providers
            .get(&provider)
            .and_then(|t| t.artist_id.as_deref())
    }

    /// Whether this track carries an identity for `provider`.
    pub fn has_provider(&self, provider: ProviderId) -> bool {
        self.providers.contains_key(&provider)
    }

    /// The on-disk path of this track's local audio file, if it has been
    /// imported or downloaded. For the `Local` provider the file path lives
    /// in `url` (a local file has no remote URL).
    pub fn local_path(&self) -> Option<String> {
        let local = self.providers.get(&ProviderId::Local)?;
        (!local.url.is_empty()).then(|| local.url.clone())
    }

    /// Record the on-disk path of this track's local audio file. Adds/updates
    /// the `Local` provider entry's `url`; does not change `source`.
    pub fn set_download_path(&mut self, path: String) {
        self.providers.entry(ProviderId::Local).or_default().url = path;
    }

    /// Insert or replace the provider-specific data on this track. Updates
    /// `source` to the first non-`Local` provider seen.
    pub fn set_provider(&mut self, provider: ProviderId, pt: ProviderTrack) {
        self.providers.insert(provider, pt);
        if self.source == ProviderId::Local && provider != ProviderId::Local {
            self.source = provider;
        }
    }

    /// Whether this track can be downloaded from `provider`.
    pub fn can_download_from(&self, provider: ProviderId) -> bool {
        provider.capabilities().download && self.providers.contains_key(&provider)
    }

    /// Pick the best stream+download provider for playback, preferring
    /// `preferred` (e.g. the default provider) then the source, then any
    /// stream-capable provider.
    pub fn best_stream_provider(&self, preferred: ProviderId) -> Option<ProviderId> {
        let candidates: Vec<ProviderId> = self
            .providers
            .keys()
            .copied()
            .filter(|p| p.capabilities().stream && p.capabilities().download)
            .collect();
        if candidates.contains(&preferred) {
            return Some(preferred);
        }
        if candidates.contains(&self.source) {
            return Some(self.source);
        }
        candidates.first().copied()
    }

    /// A stable identity key used to de-duplicate recently-played entries and
    /// Media-control metadata. Built from title + artist so the same song played from
    /// different providers collapses to one history entry.
    pub fn dedup_key(&self) -> String {
        format!("{}|{}", self.title, self.artist)
    }

    /// The search query used to resolve this track on a provider: the title
    /// alone when there is no artist, otherwise `title artist`.
    pub fn search_query(&self) -> String {
        if self.artist.is_empty() {
            self.title.clone()
        } else {
            format!("{} {}", self.title, self.artist)
        }
    }

    /// The id for this track's source provider (display/identity key).
    pub fn primary_id(&self) -> &str {
        self.provider_id(self.source).unwrap_or("")
    }

    /// The url for this track's source provider.
    pub fn primary_url(&self) -> &str {
        self.provider_url(self.source).unwrap_or("")
    }

    /// The public page for this track's album, when the album id addresses one
    /// (see [`ProviderId::album_page_url`](crate::providers::ProviderId::album_page_url)).
    pub fn album_page_url(&self) -> Option<String> {
        self.album()
            .and_then(|album| self.source.album_page_url(&album.id))
    }

    /// The public web page for this track, preferring the source provider and
    /// falling back to any other carrier that has one. `None` when no provider
    /// identity this track carries addresses a page.
    pub fn web_url(&self) -> Option<String> {
        let source = self.source;
        std::iter::once(source)
            .chain(self.providers.keys().copied().filter(|p| *p != source))
            .find_map(|p| self.providers.get(&p).and_then(|pt| p.track_page_url(pt)))
    }

    /// A stable cache key namespacing the source provider with its id, used to
    /// key the download registry, lyrics cache, and normalization gains. See
    /// [`cache_key`](ProviderId::cache_key), which owns the `slug:id` format
    /// shared with the stream cache index (`streams/cache_index.json`).
    pub fn cache_key(&self) -> String {
        self.source.cache_key(self.primary_id())
    }

    /// Build a `Track` owned by `provider`, carrying that provider's id/url in
    /// `providers` and set as `source`. Centralizes the invariant that the
    /// `source` provider is always present in `providers`. Provider-specific
    /// display metadata (`duration`/`thumbnail`/`album`) lives on the
    /// `ProviderTrack`.
    #[allow(clippy::too_many_arguments)]
    pub fn from_provider(
        provider: ProviderId,
        id: String,
        url: String,
        title: impl Into<String>,
        artist_name: impl Into<String>,
        duration: u32,
        thumbnail: impl Into<String>,
        album: Option<TrackAlbum>,
        artist_id: Option<String>,
    ) -> Self {
        let mut providers = ProviderMap::new();
        providers.insert(
            provider,
            ProviderTrack {
                id,
                url,
                artist_id,
                duration,
                thumbnail: thumbnail.into(),
                album,
                play_count: 0,
            },
        );
        Self {
            title: title.into(),
            artist: artist_name.into(),
            source: provider,
            providers,
        }
    }

    #[allow(clippy::too_many_arguments)]
    pub fn from_provider_with_count(
        provider: ProviderId,
        id: String,
        url: String,
        title: impl Into<String>,
        artist_name: impl Into<String>,
        duration: u32,
        thumbnail: impl Into<String>,
        album: Option<TrackAlbum>,
        artist_id: Option<String>,
        play_count: u64,
    ) -> Self {
        let mut track = Self::from_provider(
            provider,
            id,
            url,
            title,
            artist_name,
            duration,
            thumbnail,
            album,
            artist_id,
        );
        if let Some(pt) = track.providers.get_mut(&provider) {
            pt.play_count = play_count;
        }
        track
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub enum QueueTab {
    #[default]
    Queue,
    RecentlyPlayed,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct PlayQueue {
    pub tracks: Vec<Track>,
    pub recently_played: VecDeque<Track>,
    pub queue_tab: QueueTab,
}

impl PlayQueue {
    pub const fn new() -> Self {
        Self {
            tracks: Vec::new(),
            recently_played: VecDeque::new(),
            queue_tab: QueueTab::Queue,
        }
    }

    pub fn current(&self) -> Option<&Track> {
        self.tracks.first()
    }

    /// Pop the current (first) track off the front of the queue after it has
    /// finished playing, making the next track the new current.
    pub fn advance(&mut self) -> bool {
        if self.tracks.is_empty() {
            false
        } else {
            self.tracks.remove(0);
            true
        }
    }

    /// Record a track as just-played and push it onto `recently_played`.
    /// Deduplicates by dedup key, keeping most-recent-first. Trims to `max_len`.
    pub fn record_played(&mut self, track: &Track, max_len: usize) {
        let key = track.dedup_key();
        self.recently_played.retain(|t| t.dedup_key() != key);
        self.recently_played.push_front(track.clone());
        while self.recently_played.len() > max_len {
            self.recently_played.pop_back();
        }
    }

    pub fn previous_pos_filtered(&self, filter: impl Fn(&Track) -> bool) -> Option<usize> {
        self.recently_played.iter().position(filter)
    }

    /// Restore the track at `pos` in `recently_played` to the front of the
    /// queue (becomes the new current track), dropping everything before it.
    /// `pos` comes from [`Self::previous_pos_filtered`] and must be in bounds.
    pub fn restore_previous(&mut self, pos: usize) {
        debug_assert!(pos < self.recently_played.len());
        if let Some(track) = self.recently_played.drain(..=pos).next_back() {
            self.tracks.insert(0, track);
        }
    }

    pub fn remove_recent_at(&mut self, indices: &[usize]) -> usize {
        if indices.is_empty() {
            return 0;
        }
        let mut targets = crate::util::sorted_targets(indices);
        let original = self.recently_played.len();
        let mut i = 0usize;
        self.recently_played.retain(|_| {
            let drop_it = matches!(targets.peek(), Some(&r) if r == i);
            if drop_it {
                targets.next();
            }
            i += 1;
            !drop_it
        });
        original - self.recently_played.len()
    }

    pub fn set_queue(&mut self, tracks: Vec<Track>, max_len: usize) {
        let old = self.current().cloned();
        let new_key = tracks.first().map(Track::cache_key);
        if let (Some(old), Some(new_key)) = (old, new_key) {
            if old.cache_key() != new_key {
                self.record_played(&old, max_len);
            }
        }
        self.tracks = tracks;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_track(id: &str, url: &str) -> Track {
        let mut t = Track {
            title: format!("Track {id}"),
            artist: "Artist".into(),
            source: ProviderId::YouTube,
            providers: HashMap::new(),
        };
        t.set_provider(
            ProviderId::YouTube,
            ProviderTrack {
                id: id.into(),
                url: url.into(),
                artist_id: None,
                duration: 10,
                thumbnail: String::new(),
                album: None,
                play_count: 0,
            },
        );
        t
    }

    #[test]
    fn play_queue_advance_and_restore_previous() {
        let mut q = PlayQueue::new();
        q.tracks = vec![
            make_track("1", "url1"),
            make_track("2", "url2"),
            make_track("3", "url3"),
        ];
        assert_eq!(
            q.current().map(|t| t.provider_id(ProviderId::YouTube)),
            Some(Some("1"))
        );

        assert!(q.advance());
        assert_eq!(
            q.current().map(|t| t.provider_id(ProviderId::YouTube)),
            Some(Some("2"))
        );

        let t1 = make_track("1", "url1");
        q.record_played(&t1, 50);
        q.restore_previous(0);
        assert_eq!(
            q.current().map(|t| t.provider_id(ProviderId::YouTube)),
            Some(Some("1"))
        );

        assert!(q.advance());
        assert_eq!(
            q.current().map(|t| t.provider_id(ProviderId::YouTube)),
            Some(Some("2"))
        );
        assert!(q.advance());
        assert_eq!(
            q.current().map(|t| t.provider_id(ProviderId::YouTube)),
            Some(Some("3"))
        );
        assert!(q.advance());
        assert!(q.current().is_none());
        assert!(!q.advance());
    }

    #[test]
    fn play_queue_empty() {
        let mut q = PlayQueue::new();
        assert!(q.current().is_none());
        assert!(!q.advance());
        assert!(q.current().is_none());
    }

    #[test]
    fn restore_previous_drains_through_pos() {
        let mut q = PlayQueue::new();
        q.tracks = vec![make_track("9", "url9")];
        for id in ["1", "2", "3"] {
            q.record_played(&make_track(id, &format!("url{id}")), 50);
        }
        // Most-recent-first: [3, 2, 1]. Restoring index 1 drops "3" and
        // brings back "2", leaving "1" in history.
        q.restore_previous(1);
        assert_eq!(
            q.current().map(|t| t.provider_id(ProviderId::YouTube)),
            Some(Some("2"))
        );
        let recent: Vec<_> = q
            .recently_played
            .iter()
            .map(|t| t.provider_id(ProviderId::YouTube).unwrap_or(""))
            .collect();
        assert_eq!(recent, vec!["1"]);
    }

    #[test]
    fn record_played_order_and_dedup() {
        let mut q = PlayQueue::new();
        let t1 = make_track("1", "url1");
        let t2 = make_track("2", "url2");
        let t3 = make_track("3", "url3");

        q.record_played(&t1, 50);
        q.record_played(&t2, 50);
        q.record_played(&t3, 50);

        assert_eq!(q.recently_played.len(), 3);
        assert_eq!(
            q.recently_played[0].provider_id(ProviderId::YouTube),
            Some("3")
        );
        assert_eq!(
            q.recently_played[2].provider_id(ProviderId::YouTube),
            Some("1")
        );

        q.record_played(&t2, 50);
        assert_eq!(q.recently_played.len(), 3);
        assert_eq!(
            q.recently_played[0].provider_id(ProviderId::YouTube),
            Some("2")
        );
        assert_eq!(
            q.recently_played[1].provider_id(ProviderId::YouTube),
            Some("3")
        );
        assert_eq!(
            q.recently_played[2].provider_id(ProviderId::YouTube),
            Some("1")
        );
    }

    #[test]
    fn remove_recent_at_unsorted_and_dedup() {
        let mut q = PlayQueue::new();
        for i in 1..=5 {
            q.recently_played
                .push_back(make_track(&i.to_string(), &format!("url{i}")));
        }
        assert_eq!(q.remove_recent_at(&[3, 0, 3, 99]), 2);
        let ids: Vec<_> = q
            .recently_played
            .iter()
            .map(|t| t.provider_id(ProviderId::YouTube).unwrap_or(""))
            .collect();
        assert_eq!(ids, vec!["2", "3", "5"]);
    }

    #[test]
    fn record_played_truncates_to_max() {
        let mut q = PlayQueue::new();
        for i in 1..=60 {
            q.record_played(&make_track(&i.to_string(), &format!("url{i}")), 50);
        }
        assert_eq!(q.recently_played.len(), 50);
        assert_eq!(
            q.recently_played[0].provider_id(ProviderId::YouTube),
            Some("60")
        );
        assert_eq!(
            q.recently_played[49].provider_id(ProviderId::YouTube),
            Some("11")
        );
    }

    #[test]
    fn cache_key_uses_slug_prefix() {
        let track = make_track("abc123", "url");
        assert_eq!(track.cache_key(), "youtube:abc123");
        assert_eq!(
            ProviderId::SoundCloud.cache_key("abc123"),
            "soundcloud:abc123"
        );
        assert_eq!(ProviderId::LastFm.cache_key("x"), "lastfm:x");
    }

    #[test]
    fn web_url_prefers_the_source_provider_then_any_carrier() {
        let mut t = make_track("abc123", "https://youtube.com/watch?v=abc123");
        assert_eq!(
            t.web_url().as_deref(),
            Some("https://youtube.com/watch?v=abc123")
        );

        // MusicBrainz carries no url, so the page is built from the MBID.
        t.set_provider(
            ProviderId::MusicBrainz,
            ProviderTrack {
                id: "mbid-1".into(),
                ..Default::default()
            },
        );
        assert_eq!(
            t.web_url().as_deref(),
            Some("https://youtube.com/watch?v=abc123")
        );
        t.source = ProviderId::MusicBrainz;
        assert_eq!(
            t.web_url().as_deref(),
            Some("https://musicbrainz.org/track/mbid-1")
        );

        // No page anywhere: a Bandcamp source with a direct MP3 url.
        let mut bc = Track {
            title: "T".into(),
            artist: "A".into(),
            source: ProviderId::Bandcamp,
            providers: HashMap::new(),
        };
        bc.set_provider(
            ProviderId::Bandcamp,
            ProviderTrack {
                id: "12345".into(),
                url: "https://t4.bcbits.com/stream/abc/file.mp3".into(),
                ..Default::default()
            },
        );
        assert_eq!(bc.web_url(), None);
    }

    #[test]
    fn queue_tab_serde() {
        let json = r#"{"tracks":[],"recently_played":[],"queue_tab":"RecentlyPlayed"}"#;
        let q: PlayQueue = serde_json::from_str(json).unwrap();
        assert_eq!(q.queue_tab, QueueTab::RecentlyPlayed);

        let serialized = serde_json::to_string(&q).unwrap();
        let restored: PlayQueue = serde_json::from_str(&serialized).unwrap();
        assert_eq!(restored.queue_tab, QueueTab::RecentlyPlayed);
    }
}
