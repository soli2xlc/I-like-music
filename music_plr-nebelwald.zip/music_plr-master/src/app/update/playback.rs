use std::path::PathBuf;

use tracing::debug;

use super::{
    is_main_pane, MusicPlayer, Track, TrackPos, MANUAL_SEARCH_PANE_ID, QUEUE_PANE_ID,
    RECENT_PANE_ID,
};
use crate::{
    app::{pane::PaneId, ViewKind},
    data::{cache::StreamCache, JsonStore},
    load_state::LoadState,
    providers::ProviderId,
};

impl MusicPlayer {
    pub fn handle_play_track(&mut self, pos: TrackPos) {
        let TrackPos { index, pane } = pos;
        let track = self.get_track_at(pos);
        if let Some(track) = &track {
            if self.is_trashed(track) {
                return;
            }
        }
        match pane {
            RECENT_PANE_ID => {
                if let Some(track) = track {
                    self.set_queue(vec![track]);
                }
            }
            QUEUE_PANE_ID => {
                let queue = self.queue.tracks.get(index..).unwrap_or(&[]);
                self.set_queue(queue.to_vec());
            }
            // The popup's results are a transient list inside a dialog, so
            // there is no view to record as the origin.
            MANUAL_SEARCH_PANE_ID => {
                let queue = self.view_tracks_in(pane).get(index..).unwrap_or(&[]);
                self.set_queue(queue.to_vec());
            }
            _ => {
                let queue = self.view_tracks_in(pane).get(index..).unwrap_or(&[]);
                self.set_queue(queue.to_vec());
                self.record_now_playing_origin();
            }
        }
    }

    /// Snapshot the current view as the source of the track being played.
    pub(super) fn record_now_playing_origin(&mut self) {
        self.now_playing_from = Some(self.view_data().clone());
    }

    /// Persist `track` back into the list it came from (`pos`), so a resolved
    /// provider id survives and the source view/queue reflects it.
    pub(super) fn set_track_at(&mut self, pos: TrackPos, track: Track) {
        let TrackPos { index, pane } = pos;
        if pane == QUEUE_PANE_ID {
            if let Some(t) = self.queue.tracks.get_mut(index) {
                *t = track;
            }
        } else if pane == MANUAL_SEARCH_PANE_ID {
            if let Some(manual) = self.edit_manual_mut() {
                if let LoadState::Ready(tracks) = &mut manual.results {
                    if let Some(t) = tracks.get_mut(index) {
                        *t = track;
                    }
                }
            }
        } else if is_main_pane(pane) {
            let view = self.view_data_in_mut(pane);
            if let Some(t) = view.tracks_mut().and_then(|ts| ts.get_mut(index)) {
                *t = track.clone();
            }
            match &view.kind {
                ViewKind::Playlist(entry) => {
                    let sp = entry.index;
                    if let Some(pl) = self.playlists.playlists.get_mut(sp) {
                        if let Some(t) = pl.tracks.get_mut(index) {
                            *t = track;
                        }
                    }
                    self.playlists.save();
                }
                ViewKind::Trashbin => {
                    if let Some(t) = self.trashbin.tracks.get_mut(index) {
                        *t = track;
                    }
                    self.trashbin.save();
                }
                _ => {}
            }
        }
    }

    /// Play the first non-trashed track (preferring its own source when
    /// streamable, else the default provider), replace the queue with
    /// `tracks`, and persist the session. An empty `tracks` clears the queue
    /// without playing. Trashed tracks stay in the queue and are skipped when
    /// playback reaches them.
    pub fn set_queue(&mut self, tracks: Vec<Track>) {
        self.queue
            .set_queue(tracks, self.config.max_recently_played);
        self.skip_trashed_and_play_current();
    }

    /// Advance past trashed tracks at the queue front without recording them
    /// as played, then start the new current track if any. The single choke
    /// point for (re)starting playback on a queue that may begin with
    /// trashed tracks.
    fn skip_trashed_and_play_current(&mut self) {
        while self.queue.current().is_some_and(|t| self.is_trashed(t)) {
            self.queue.advance();
        }
        if let Some(first) = self.queue.current().cloned() {
            let preferred = if first.best_stream_provider(first.source).is_some() {
                first.source
            } else {
                self.config.default_provider
            };
            self.play_track_internal(&first, preferred);
        }
        self.save_session();
        self.media_controls_dirty = true;
    }

    /// Play `pos` through `provider`. If the track already carries that
    /// provider's id, switch its source and play directly; otherwise resolve
    /// the id on `provider` in the background, then stream. Either way the
    /// track's `source` becomes `provider` so the chosen provider's metadata
    /// is what displays and drives playback.
    pub fn play_track_via_provider(&mut self, provider: ProviderId, pos: TrackPos) {
        let Some(track) = self.get_track_at(pos) else {
            return;
        };
        if self.is_trashed(&track) {
            return;
        }
        if track.has_provider(provider) {
            let mut t = track;
            t.source = provider;
            // Persist the source switch back into the list it came from (a
            // playlist is written to disk; the queue is saved via the session)
            // so the chosen provider survives a restart.
            self.set_track_at(pos, t);
            self.handle_play_track(pos);
        } else {
            self.resolve_provider(provider, track, pos, true);
        }
    }

    /// Download the context menu's target tracks from `provider`. Tracks
    /// lacking the provider id are resolved first (best-effort; the resolve
    /// flow stores the id and then downloads).
    pub fn download_track_via_provider(&mut self, provider: ProviderId) {
        let Some(menu) = self.take_context_menu() else {
            return;
        };
        let pane = menu.pos.pane;
        let indices = menu.target_indices;
        let mut to_download: Vec<Track> = Vec::new();
        for &idx in &indices {
            if let Some(track) = self.get_track_at(TrackPos::new(idx, pane)) {
                if track.can_download_from(provider) {
                    to_download.push(track);
                } else {
                    let pos = TrackPos::new(idx, pane);
                    self.resolve_provider(provider, track, pos, false);
                }
            }
        }
        if !to_download.is_empty() {
            let msg = (self.strings.downloading_n)(to_download.len());
            self.notify(msg);
            for track in to_download {
                self.spawn_download_thread_for(provider, track);
            }
        }
    }

    /// Resolve a track's id on `provider` in the background. If `play` is true
    /// the resolved track is streamed; otherwise it is downloaded.
    fn resolve_provider(&mut self, provider: ProviderId, track: Track, pos: TrackPos, play: bool) {
        let msg = (self.strings.resolving_on)(&track.title, provider.label());
        self.notify(msg);
        let rid = if is_main_pane(pos.pane) && self.panes.contains_key(&pos.pane) {
            self.slot_request_id(pos.pane)
        } else {
            0
        };
        let tx = self.result_tx.clone();
        std::thread::spawn(move || {
            let resolved = crate::providers::resolve_id(provider, &track);
            let _ = tx.send(match resolved {
                Ok(resolved) => crate::app::BackendResult::ProviderResolved {
                    original: track,
                    provider,
                    resolved,
                    rid,
                    pos,
                    play,
                },
                Err(e) => crate::app::BackendResult::ProviderResolveError {
                    title: track.title,
                    provider,
                    message: e.to_string(),
                },
            });
        });
    }

    pub fn play_track_internal(&mut self, track: &Track, preferred: ProviderId) {
        self.track_loading = true;
        self.progress = 0.0;
        self.progress_at = std::time::Instant::now();
        // The active track changed: drop any cached lyrics so the overlay
        // re-fetches for the new track when reopened.
        self.clear_lyrics_for_track_change();

        // Look up any cached normalization gain (1.0 when disabled or unknown).
        let gain = self.normalization_gain_for(track);

        // The file to analyze for loudness: complete for downloaded/local/
        // cached tracks, still downloading for a fresh stream.
        let mut analysis_path: Option<PathBuf> = None;
        let mut streaming = false;

        // Prefer an on-disk local file (downloaded or imported) over
        // streaming. A track may carry its own local path on its `Local`
        // provider entry even while also being streamable from another
        // provider, so this check runs before any streaming resolution.
        let dl_key = track.cache_key();
        let local_path = track
            .local_path()
            .or_else(|| self.download_registry.path_for(&dl_key));
        if let Some(dl_path) = local_path {
            let path = PathBuf::from(&dl_path);
            if path.exists() {
                debug!("Playing local file: {}", path.display());
                self.audio
                    .play_cached(path.clone(), track.duration() as f32, gain);
                self.pending_cache_id = None;
                analysis_path = Some(path);
            }
        }

        if analysis_path.is_none() {
            match track.best_stream_provider(preferred) {
                None => {
                    // No stream-capable provider right now (e.g. yt-dlp is
                    // missing). A track that was previously streamed may still
                    // have a complete copy in the stream cache, and
                    // downloaded/imported tracks carry a local path — both play
                    // without yt-dlp, so try them before giving up.
                    let cached = track.providers.keys().find_map(|p| {
                        let id = track.provider_id(*p)?;
                        (self.stream_cache.contains(*p, id)).then(|| StreamCache::path_for(*p, id))
                    });
                    if let Some(path) = cached.filter(|p| p.exists()) {
                        debug!("Playing cached copy (no yt-dlp needed): {}", path.display());
                        self.audio
                            .play_cached(path.clone(), track.duration() as f32, gain);
                        self.pending_cache_id = None;
                        analysis_path = Some(path);
                    }
                    if analysis_path.is_none() {
                        // Truly nothing playable: explain why and drop the
                        // spinner — nothing downstream will clear it.
                        self.track_loading = false;
                        if track.providers.keys().any(|p| p.uses_ytdlp()) {
                            self.notify(self.strings.deps_play_requires_yt_dlp);
                        } else {
                            self.notify(self.strings.deps_source_not_playable);
                        }
                        return;
                    }
                }
                Some(provider) => {
                    let id = track.provider_id(provider).unwrap_or_default().to_string();

                    if self.stream_cache.contains(provider, &id) {
                        let path = StreamCache::path_for(provider, &id);
                        debug!("Playing from cache: {}", path.display());
                        self.audio
                            .play_cached(path.clone(), track.duration() as f32, gain);
                        self.pending_cache_id = None;
                        analysis_path = Some(path);
                    } else {
                        let url = track.provider_url(provider).unwrap_or_default().to_string();
                        self.pending_cache_id = Some(crate::app::PendingCache {
                            provider_id: provider,
                            id: id.clone(),
                        });
                        let cache_path = StreamCache::path_for(provider, &id);
                        debug!("Streaming ({}): {}", provider.label(), cache_path.display());
                        if provider.uses_ytdlp() {
                            self.audio.play_stream_cache(
                                &url,
                                track.duration() as f32,
                                cache_path.clone(),
                                gain,
                            );
                        } else {
                            self.audio.play_stream_http(
                                &url,
                                track.duration() as f32,
                                cache_path.clone(),
                                gain,
                            );
                        }
                        streaming = true;
                        analysis_path = Some(cache_path);
                    }
                }
            }
        }

        // Kick off background loudness analysis so subsequent plays are
        // normalized. A streaming track's cache is incomplete until it
        // finishes downloading, so defer analysis to the tick loop.
        if self.config.volume_normalization
            && !self.normalization_cache.contains_key(&track.cache_key())
        {
            if streaming {
                self.pending_normalization_id = Some(track.cache_key());
            } else if let Some(path) = analysis_path {
                let key = track.cache_key();
                self.pending_normalization_id = Some(key.clone());
                self.request_normalization_analysis(&key, path);
            }
        }
    }

    /// Normalization gain for `track`: the cached value when normalization is
    /// enabled and known, otherwise 1.0 (no change).
    fn normalization_gain_for(&self, track: &Track) -> f32 {
        if self.config.volume_normalization {
            self.normalization_cache
                .get(&track.cache_key())
                .copied()
                .unwrap_or(1.0)
        } else {
            1.0
        }
    }

    /// Decode `path` in the background to compute its normalization gain and
    /// report it back via the result channel for caching.
    pub(super) fn request_normalization_analysis(&self, track_id: &str, path: PathBuf) {
        let tx = self.result_tx.clone();
        let id = track_id.to_string();
        std::thread::spawn(move || {
            if let Some(gain) = crate::audio::compute_normalization_gain(&path) {
                let _ = tx.send(crate::app::BackendResult::NormalizationComputed(id, gain));
            }
        });
    }

    pub fn handle_reorder_queue(&mut self, drop_idx: usize, indices: &[usize]) -> Vec<usize> {
        let selection = std::mem::take(&mut self.queue_selected_indices);
        let new_positions =
            crate::util::reorder_tracks(&mut self.queue.tracks, drop_idx, indices, selection);
        self.save_session();
        new_positions
    }

    pub fn handle_add_to_queue(&mut self, pane: PaneId, indices: &[usize]) {
        let tracks: Vec<Track> = indices
            .iter()
            .filter_map(|&i| self.get_track_at(TrackPos::new(i, pane)))
            .collect();
        if tracks.is_empty() {
            return;
        }
        let inserted = tracks.len();
        for (j, track) in tracks.into_iter().enumerate() {
            self.queue.tracks.insert(j + 1, track);
        }
        self.save_session();
        let tr = self.strings;
        self.notify((tr.added_to)(inserted, tr.queue));
        self.clear_selection_if_touched_in(pane, indices);
    }

    pub fn handle_remove_from_queue_batch(&mut self, indices: &[usize]) {
        let removed = crate::util::remove_at(&mut self.queue.tracks, indices);
        self.media_controls_dirty = true;
        self.save_session();
        let tr = self.strings;
        let msg = (tr.removed_from)(removed, tr.queue);
        self.notify(msg);
        self.clear_selection_if_touched_in(QUEUE_PANE_ID, indices);
    }

    pub fn handle_remove_from_recent_batch(&mut self, indices: &[usize]) {
        let removed = self.queue.remove_recent_at(indices);
        self.save_session();
        let tr = self.strings;
        let msg = (tr.removed_from)(removed, tr.recently_played);
        self.notify(msg);
        self.clear_selection_if_touched_in(RECENT_PANE_ID, indices);
    }

    pub fn toggle_play_pause(&mut self) {
        if let Some(track) = self.queue.current().cloned() {
            if self.is_playing {
                self.progress = self.playback_progress();
                self.is_playing = false;
                self.audio.pause();
                self.track_loading = false;
            } else if self.is_trashed(&track) {
                self.skip_trashed_and_play_current();
            } else if self.audio.has_output() {
                self.progress_at = std::time::Instant::now();
                self.is_playing = true;
                self.audio.resume();
            } else {
                self.play_track_internal(&track, track.source);
            }
        }
        self.media_controls_dirty = true;
    }

    pub fn next_track(&mut self) {
        if let Some(old) = self.queue.current().cloned() {
            self.queue
                .record_played(&old, self.config.max_recently_played);
            self.queue.advance();
        }

        while self.queue.current().is_some_and(|t| self.is_trashed(t)) {
            self.queue.advance();
        }

        if let Some(t) = self.queue.current() {
            self.track_loading = true;
            let t = t.clone();
            self.play_track_internal(&t, t.source);
            self.save_session();
            self.media_controls_dirty = true;
        }
    }

    pub fn previous_track(&mut self) {
        let Some(prev_pos) = self.queue.previous_pos_filtered(|t| !self.is_trashed(t)) else {
            return;
        };
        self.queue.restore_previous(prev_pos);
        self.track_loading = true;
        if let Some(t) = self.queue.current() {
            let t = t.clone();
            self.play_track_internal(&t, t.source);
        }
        self.save_session();
        self.media_controls_dirty = true;
    }

    pub fn set_volume(&mut self, vol: f32) {
        self.volume = vol.clamp(0.0, 1.0);
        self.audio.set_volume(self.volume);
        self.save_session();
        self.media_controls_dirty = true;
    }

    pub fn adjust_volume(&mut self, delta: f32) {
        if delta > 0.0 {
            self.muted_volume = None;
        }
        self.set_volume(self.volume + delta);
    }

    pub fn toggle_mute(&mut self) {
        if self.volume > 0.0 {
            self.muted_volume = Some(self.volume);
            self.set_volume(0.0);
        } else {
            let restore = self.muted_volume.take().unwrap_or(0.8);
            self.set_volume(restore);
        }
    }

    pub fn seek_by_seconds(&mut self, delta: f32) {
        if self.duration <= 0.0 {
            return;
        }
        let pos = self.playback_progress() * self.duration + delta;
        self.seek(pos / self.duration);
    }

    pub fn seek(&mut self, frac: f32) {
        let frac = frac.clamp(0.0, 1.0);
        self.progress = frac;
        self.progress_at = std::time::Instant::now();
        self.audio
            .seek(std::time::Duration::from_secs_f32(frac * self.duration));
        self.media_controls_dirty = true;
    }

    /// Live playback position as a fraction: the anchor advanced by the wall
    /// clock while playing. The progress bar draws from this without polling;
    /// slow ticks re-anchor it against the audio thread to correct drift.
    pub fn playback_progress(&self) -> f32 {
        if self.is_playing && self.duration > 0.0 {
            (self.progress + self.progress_at.elapsed().as_secs_f32() / self.duration)
                .clamp(0.0, 1.0)
        } else {
            self.progress.clamp(0.0, 1.0)
        }
    }

    /// Seek to an absolute playback position in seconds (used by clicking a
    /// synced lyrics line).
    pub fn seek_to_seconds(&mut self, secs: f32) {
        if self.duration <= 0.0 {
            return;
        }
        let frac = (secs / self.duration).clamp(0.0, 1.0);
        self.seek(frac);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::data::config;

    fn player() -> MusicPlayer {
        MusicPlayer::new_with(config::Config::default())
    }

    #[test]
    fn unplayable_track_does_not_stick_loading() {
        let mut p = player();
        p.play_track_internal(&Track::default(), ProviderId::YouTube);
        assert!(!p.track_loading);
    }

    #[test]
    fn progress_interpolates_from_the_anchor_while_playing() {
        let mut p = player();
        p.duration = 100.0;
        p.progress = 0.5;
        p.progress_at = std::time::Instant::now();
        p.is_playing = true;
        assert!((p.playback_progress() - 0.5).abs() < 0.02);
        p.is_playing = false;
        assert_eq!(p.playback_progress(), 0.5);
    }
}
