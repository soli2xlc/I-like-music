use iced::widget::Id;

use super::{
    is_main_pane,
    operation::{ContainingList, ListGeometry},
    pane_first_index, BackendResult, Message, MusicPlayer, Task, Track, TrackPos, DOUBLE_CLICK_MS,
    PREPEND, QUEUE_PANE_ID, RECENT_PANE_ID,
};
use crate::{
    app::{
        interaction::{DropTarget, Pressed, PressedDrag},
        pane::PaneId,
        ui::{track_list_id, QUEUE_LIST_ID},
        ViewKind,
    },
    data::{
        library::{LibraryItem, LibraryKind},
        JsonStore,
    },
};

impl MusicPlayer {
    pub fn handle_left_release(&mut self) -> Task<Message> {
        // Clicks on a search input arrive as `SearchInputClicked` straight
        // from the widget, so this path never needs the cursor: a press-less
        // release only dismisses open search histories.
        if self.drag.pressed.is_none() {
            if self.suppress_history_close {
                self.suppress_history_close = false;
            } else {
                for pane in self.pane_ids_unsorted() {
                    if self.pane(pane).show_search_history {
                        self.pane_mut(pane).show_search_history = false;
                    }
                }
            }
            self.drag.clear_hovered_search_history();
            self.drag.stop();
            return Task::none();
        }
        for pane in self.pane_ids_unsorted() {
            if self.pane(pane).show_search_history {
                self.pane_mut(pane).show_search_history = false;
            }
        }
        self.drag.clear_hovered_search_history();

        let Some(pressed) = self.drag.pressed.take().map(|pd| pd.what) else {
            self.drag.stop();
            return Task::none();
        };

        let mut nav_task = Task::none();

        if self.drag.drag_active {
            match pressed {
                Pressed::Track(pos) => self.handle_track_drop(pos),
                Pressed::Card(item, _) => {
                    if let Some(target) = self
                        .card_drop_target(self.bounds.get_containing(self.drag.cursor_pos).as_ref())
                    {
                        nav_task = self.handle_card_drop(item, target);
                    }
                }
                Pressed::Playlist(_) => self.handle_playlist_drop(),
            }
        } else {
            match pressed {
                Pressed::Track(pos) => {
                    self.toggle_selection(pos);
                }
                Pressed::Card(item, pane) => {
                    let target = pane.unwrap_or(self.focused_pane_id);
                    self.focused_pane_id = target;
                    nav_task = self.open_card(target, &item.clone().into());
                }
                // A click without a drag selects the playlist (mirrors how a
                // library card opens on a plain click).
                Pressed::Playlist(i) => {
                    nav_task = self.handle_select_playlist(i);
                }
            }
        }

        self.drag.stop();
        nav_task
    }

    pub fn handle_drag_update(&mut self) -> Task<Message> {
        self.drag.drop_target = None;

        let Some(pressed) = self.drag.pressed.as_ref().map(|pd| &pd.what) else {
            return Task::none();
        };

        let containing = self.bounds.get_containing(self.drag.cursor_pos);

        match pressed {
            Pressed::Card(_, _) => {
                self.drag.drop_target = self.card_drop_target(containing.as_ref());
            }
            Pressed::Track(_) => {
                self.drag.drop_target = self.resolve_track_drop(containing.as_ref());
            }
            Pressed::Playlist(from) => {
                self.drag.drop_target = self.resolve_playlist_drop(*from, containing.as_ref());
            }
        }

        let Some((target, geo)) = containing else {
            return Task::none();
        };

        let Some(pane) = target.track_target() else {
            return Task::none();
        };
        if pane == RECENT_PANE_ID {
            return Task::none();
        }
        let count = self.track_count_in(pane);
        let scrollable_id = if pane == QUEUE_PANE_ID {
            QUEUE_LIST_ID
        } else {
            track_list_id(pane)
        };
        let content_height = count as f32 * crate::theme::ROW_HEIGHT;
        self.handle_drag_autoscroll(geo.bounds, geo.translation_y, content_height, scrollable_id)
    }

    /// Resolve a playlist-row reorder: the press must be over the sidebar
    /// playlist list, and the resolved insertion index must differ from the
    /// row's current position (a drop onto itself is a no-op).
    fn resolve_playlist_drop(
        &self,
        from: usize,
        containing: Option<&(ContainingList, &ListGeometry)>,
    ) -> Option<DropTarget> {
        let (list, geo) = containing?;
        if *list != ContainingList::Sidebar {
            return None;
        }
        let count = self.playlists.playlists.len();
        if from >= count {
            return None;
        }
        let to = self.sidebar_insertion_index(geo, count);
        // Dragging a row onto its own slot (or the gap just below it) is a
        // no-op.
        if to == from || to == from + 1 {
            return None;
        }
        Some(DropTarget::PlaylistReorder { from, to })
    }

    fn resolve_track_drop(
        &self,
        containing: Option<&(ContainingList, &ListGeometry)>,
    ) -> Option<DropTarget> {
        let (list, geo) = containing?;
        if *list == ContainingList::Sidebar {
            let count = self.playlists.playlists.len();
            let cursor_y = self.drag.cursor_pos.y + geo.translation_y;
            let idx = nearest_row_index(&geo.rows, cursor_y).filter(|&idx| idx < count)?;
            return Some(DropTarget::PlaylistAdd(idx));
        }
        let pane = list.track_target()?;
        // Only local playlists and queue can be dropped onto
        if is_main_pane(pane) && !matches!(&self.view_data_in(pane).kind, ViewKind::Playlist(_)) {
            return None;
        }
        let drop_idx = self.compute_drop_idx(pane);
        Some(DropTarget::Track(TrackPos::new(drop_idx, pane)))
    }

    fn compute_drop_idx(&self, pane: PaneId) -> usize {
        let geo = if pane == QUEUE_PANE_ID || pane == RECENT_PANE_ID {
            self.bounds.queue.as_ref()
        } else {
            self.bounds.track_geo(pane)
        };
        let Some(geo) = geo else {
            return pane_first_index(pane);
        };
        let first = pane_first_index(pane);
        let count = self.track_count_in(pane);
        // Cursor position in the scrollable's content space (y = 0 at the top
        // of the first row).
        let cursor_y = (self.drag.cursor_pos.y - geo.bounds.y) + geo.translation_y;
        drop_index_from_cursor(cursor_y, first, count)
    }

    fn handle_drag_autoscroll(
        &self,
        bounds: iced::Rectangle,
        current_scroll: f32,
        content_height: f32,
        scrollable_id: Id,
    ) -> Task<Message> {
        let cursor = self.drag.cursor_pos;
        let y_offset = cursor.y - bounds.y;
        let list_height = bounds.height;

        let max_scroll = (content_height - list_height).max(0.0);

        if max_scroll <= 0.0 {
            return Task::none();
        }

        let edge_zone = crate::theme::DRAG_AUTO_SCROLL_ZONE;
        let scroll_speed = crate::theme::DRAG_AUTO_SCROLL_SPEED;

        let scroll_amount = if y_offset < edge_zone {
            -scroll_speed
        } else if y_offset > list_height - edge_zone {
            scroll_speed
        } else {
            0.0
        };

        if scroll_amount == 0.0 {
            return Task::none();
        }

        let new_scroll = (current_scroll + scroll_amount).clamp(0.0, max_scroll);
        if (new_scroll - current_scroll).abs() < 0.1 {
            return Task::none();
        }

        iced::widget::operation::scroll_by::<Message>(
            scrollable_id,
            iced::widget::operation::AbsoluteOffset {
                x: 0.0,
                y: scroll_amount,
            },
        )
    }

    /// Screen-space rectangle of the single drop indicator, derived from
    /// captured row geometry rather than an injected row (so the list layout
    /// is never perturbed). `None` when there is no drop target drawing an
    /// insertion line (`PlaylistAdd` highlights a row instead) or when the
    /// boundary falls outside the visible viewport.
    pub fn drop_indicator_rect(&self) -> Option<iced::Rectangle> {
        // Resolve to the targeted geometry and the 0-based insertion index
        // within its captured rows.
        let (geo, rel) = match self.drag.drop_target {
            Some(DropTarget::Playlist(i)) => (self.bounds.sidebar.as_ref()?, i),
            Some(DropTarget::Library(i)) => (self.bounds.library.as_ref()?, i),
            Some(DropTarget::PlaylistReorder { to, .. }) => (self.bounds.sidebar.as_ref()?, to),
            Some(DropTarget::Track(pos)) => {
                if pos.pane == RECENT_PANE_ID {
                    return None;
                }
                let geo = if pos.pane == QUEUE_PANE_ID {
                    self.bounds.queue.as_ref()?
                } else {
                    self.bounds.track_geo(pos.pane)?
                };
                (geo, pos.index.saturating_sub(pane_first_index(pos.pane)))
            }
            // A track dropped on the playlist list highlights the target row
            // (handled in the sidebar view) rather than drawing an insertion
            // line, so it produces no indicator rect.
            Some(DropTarget::PlaylistAdd(_)) | None => return None,
        };

        // Virtualized (queue/active) lists leave `geo.rows` empty, so their
        // boundary comes from the uniform `ROW_HEIGHT`; measured lists use
        // their captured row geometry.
        let rows = &geo.rows;
        let boundary_y = if rows.is_empty() {
            geo.bounds.y - geo.translation_y + rel as f32 * crate::theme::ROW_HEIGHT
        } else if rel == 0 {
            rows[0].y - geo.translation_y
        } else if rel <= rows.len() {
            let k = rel - 1;
            rows[k].y + rows[k].height - geo.translation_y
        } else {
            let last = rows.last().unwrap();
            last.y + last.height - geo.translation_y
        };
        if boundary_y < geo.bounds.y || boundary_y > geo.bounds.y + geo.bounds.height {
            return None;
        }
        Some(iced::Rectangle {
            x: geo.bounds.x,
            y: boundary_y - crate::theme::DROP_LINE_HEIGHT / 2.0,
            width: geo.bounds.width,
            height: crate::theme::DROP_LINE_HEIGHT,
        })
    }

    pub fn handle_track_drop(&mut self, pos: TrackPos) {
        let source = pos.pane;
        let indices = self.dragged_indices(source).to_vec();

        // Dropped on the playlist sidebar: add to that playlist (prepend). The
        // target was resolved during the drag into `drop_target` and is shown
        // by the row highlight, so there is no separate insertion bar.
        if let Some(DropTarget::PlaylistAdd(playlist_idx)) = self.drag.drop_target {
            let tracks: Vec<Track> = indices
                .iter()
                .filter_map(|&i| self.get_track_at(TrackPos::new(i, source)))
                .collect();
            let count = self
                .playlists
                .insert_tracks_at(playlist_idx, tracks.iter(), PREPEND);
            let name = &self.playlists.playlists[playlist_idx].name;
            let msg = (self.strings.added_to)(count, name);
            self.notify(msg);
            return;
        }

        let Some(DropTarget::Track(drop)) = self.drag.drop_target else {
            return;
        };
        let drop_idx = drop.index;

        // Determine if this is a cross-list copy or a same-list reorder.
        // A drop is a reorder only when source and target are the same list;
        // main-pane ids are unique per list, so pane equality decides it.
        if drop.pane == source {
            self.handle_same_list_reorder(drop.pane, drop_idx, &indices);
        } else if drop.pane == QUEUE_PANE_ID {
            self.copy_to_queue(source, &indices, drop_idx);
        } else if is_main_pane(drop.pane) {
            self.copy_from_queue(drop.pane, source, &indices, drop_idx);
        }
    }

    pub fn dragged_indices(&self, pane: PaneId) -> &[usize] {
        match &self.drag.dragged {
            Some((drag_pane, indices)) if *drag_pane == pane => indices,
            _ => &[],
        }
    }

    pub fn is_dragging_track(&self, pos: TrackPos) -> bool {
        // Sorted: cloned from the (sorted) selection, or a single index.
        self.dragged_indices(pos.pane)
            .binary_search(&pos.index)
            .is_ok()
    }

    fn copy_to_queue(&mut self, source: PaneId, indices: &[usize], drop_idx: usize) {
        let clamped = drop_idx.min(self.queue.tracks.len());
        let tracks: Vec<Track> = indices
            .iter()
            .filter_map(|&i| self.get_track_at(TrackPos::new(i, source)))
            .collect();
        let inserted = tracks.len();
        for (j, track) in tracks.into_iter().enumerate() {
            self.queue.tracks.insert(clamped + j, track);
        }
        self.save_session();
        let msg = (self.strings.added_to)(inserted, self.strings.queue);
        self.notify(msg);
    }

    /// Insert tracks from `source` into the target pane's playlist at the
    /// given drop index. `indices` are positions in the source list.
    fn copy_from_queue(
        &mut self,
        target_pane: PaneId,
        source: PaneId,
        indices: &[usize],
        drop_idx: usize,
    ) {
        let active = match &self.view_data_in(target_pane).kind {
            ViewKind::Playlist(p) => Some(p.index),
            _ => None,
        };
        let Some(sp) = active else {
            if !self.view_data_in(target_pane).is_search_like() {
                self.notify(self.strings.select_playlist_drop);
            }
            return;
        };
        if sp >= self.playlists.playlists.len() {
            return;
        }

        let clamped = drop_idx.min(self.playlists.playlists[sp].tracks.len());
        let tracks: Vec<Track> = indices
            .iter()
            .filter_map(|&i| self.get_track_at(TrackPos::new(i, source)))
            .collect();
        let inserted = self.playlists.insert_tracks_at(sp, tracks.iter(), clamped);
        self.save_session();
        if inserted > 0 {
            let msg = (self.strings.added_to)(inserted, &self.playlists.playlists[sp].name);
            self.notify(msg);
        }
    }

    /// Handle reordering within the same list. The selection is always
    /// remapped to reflect the new positions of all selected tracks — both
    /// the moved ones and any that merely shifted.
    fn handle_same_list_reorder(&mut self, pane: PaneId, drop_idx: usize, indices: &[usize]) {
        if drop_idx > self.track_count_in(pane) {
            return;
        }

        if pane == QUEUE_PANE_ID {
            self.queue_selected_indices = self.handle_reorder_queue(drop_idx, indices);
            self.save_session();
        } else if is_main_pane(pane) {
            let positions = self.handle_reorder_tracks_selected(pane, drop_idx, indices);
            self.view_data_in_mut(pane).selection = positions;
        }
    }

    fn card_drop_target(
        &self,
        containing: Option<&(ContainingList, &ListGeometry)>,
    ) -> Option<DropTarget> {
        if let Some((list, geo)) = containing {
            if *list == ContainingList::Sidebar {
                let count = self.playlists.playlists.len();
                return Some(DropTarget::Playlist(
                    self.sidebar_insertion_index(geo, count),
                ));
            }
            if *list == ContainingList::Library {
                let count = self.library.items.len();
                return Some(DropTarget::Library(
                    self.sidebar_insertion_index(geo, count),
                ));
            }
        }
        None
    }

    /// The index within a sidebar list where a drop would insert, given the
    /// cursor's position relative to the list's measured row bounds.
    fn sidebar_insertion_index(&self, geo: &ListGeometry, count: usize) -> usize {
        let cursor_y = self.drag.cursor_pos.y + geo.translation_y;
        for (i, row) in geo.rows.iter().enumerate() {
            if cursor_y < row.y + row.height / 2.0 {
                return i;
            }
        }
        geo.rows.len().min(count)
    }

    /// Reorder an existing playlist row within the sidebar list. The active
    /// `Playlist` view selection is remapped so the same playlist stays
    /// selected after its index changes.
    pub fn handle_playlist_drop(&mut self) {
        let Some(DropTarget::PlaylistReorder { from, to }) = self.drag.drop_target else {
            return;
        };
        if from >= self.playlists.playlists.len() || to > self.playlists.playlists.len() {
            return;
        }
        crate::util::move_items(&mut self.playlists.playlists, to, &[from]);
        self.playlists.save();

        // Keep the active Playlist view pointed at the same playlist. After
        // `reorder_tracks`, the moved row lands at `to - removed_before` where
        // `removed_before = from < to`. Other selections shift down by one if
        // the moved row passed above them, then shift again if the moved row
        // is inserted at or before their new position.
        let removed_before = usize::from(from < to);
        let landed = to - removed_before;
        if let ViewKind::Playlist(entry) = &mut self.view_data_mut().kind {
            if entry.index == from {
                entry.index = landed;
            } else {
                let mut new_sp = entry.index - usize::from(from < entry.index);
                if landed <= new_sp {
                    new_sp += 1;
                }
                entry.index = new_sp;
            }
        }
        self.notify(self.strings.reordered_playlist);
    }

    fn handle_card_drop(&mut self, item: LibraryItem, target: DropTarget) -> Task<Message> {
        match target {
            DropTarget::Playlist(idx) => self.create_playlist_from_card(&item, idx),
            DropTarget::Library(idx) => {
                if self.library.contains(item.kind, &item.id) {
                    if let Some(from) = self
                        .library
                        .items
                        .iter()
                        .position(|it| it.kind == item.kind && it.id == item.id)
                    {
                        // Adjust for the removed row so the indicator position
                        // maps to the post-removal list.
                        let to = if idx > from { idx - 1 } else { idx };
                        self.library.move_item(from, to);
                    }
                } else {
                    let msg = (self.strings.saved_title)(&item.title);
                    self.library.insert(item, idx);
                    self.notify(msg);
                }
                Task::none()
            }
            _ => Task::none(),
        }
    }

    /// Create a local playlist from a card at `insert_at`: make a new
    /// uniquely-named playlist, then fetch its contents in the background and
    /// fill it once they arrive. Shared by dragging a card onto a playlist or
    /// the library and the card menu's "Save as playlist".
    pub(crate) fn create_playlist_from_card(
        &mut self,
        item: &LibraryItem,
        insert_at: usize,
    ) -> Task<Message> {
        let idx = self.playlists.create_at(&item.title, insert_at);
        let name = self.playlists.playlists[idx].name.clone();

        let kind_str = match item.kind {
            LibraryKind::Artist => "artist",
            LibraryKind::Album => "album",
            LibraryKind::Playlist => "playlist",
        };
        let id = item.id.clone();
        let tx = self.result_tx.clone();
        let provider = item.provider;
        self.notify((self.strings.creating_playlist)(&name));
        let rid = self.request_ids.next();
        Self::spawn_backend_thread(
            rid,
            move || crate::providers::browse(provider, &id, kind_str),
            move |(tracks, _)| BackendResult::CardPlaylistReady(idx, name, tracks),
            tx,
        );

        // Jump to the freshly created (initially empty) playlist view; tracks
        // stream in as the browse result arrives. Select it directly (rather
        // than `handle_select_playlist`) so it activates even when the drop
        // index coincides with the currently selected playlist.
        self.navigate_to_playlist(idx)
    }

    /// Arm a press for dragging. A track row also supports double-click (play
    /// + select); a card (artist/album/playlist) opens on a plain click.
    ///
    /// The press-time cursor is stale (cursor tracking runs only while
    /// pressed), so the origin recorded here is re-anchored by the first
    /// `CursorMoved`; the threshold is promoted there, this only arms.
    pub fn handle_drag_press(&mut self, pressed: Pressed) {
        self.drag.claim_mouse();
        match pressed {
            Pressed::Track(pos) => {
                if is_main_pane(pos.pane) {
                    self.focused_pane_id = pos.pane;
                }
                let now = std::time::Instant::now();
                // Comparing the full position, not just the index, keeps a click
                // in one list from completing a double-click begun in another.
                let is_double = self.last_click.is_some_and(|(last_pos, last_time)| {
                    last_pos == pos && now.duration_since(last_time).as_millis() < DOUBLE_CLICK_MS
                });
                self.last_click = Some((pos, now));
                if is_double {
                    self.drag.pressed = None;
                    self.handle_play_track(pos);
                    return;
                }
                let sel = self.selection_in(pos.pane);
                let indices = if sel.binary_search(&pos.index).is_ok() {
                    sel.to_vec()
                } else {
                    vec![pos.index]
                };
                self.drag.dragged = Some((pos.pane, indices));
                self.drag.pressed = Some(PressedDrag {
                    what: Pressed::Track(pos),
                    origin: self.drag.cursor_pos,
                });
            }
            Pressed::Card(_, Some(pane)) => {
                self.focused_pane_id = pane;
                self.drag.pressed = Some(PressedDrag {
                    what: pressed,
                    origin: self.drag.cursor_pos,
                });
            }
            _ => {
                self.drag.pressed = Some(PressedDrag {
                    what: pressed,
                    origin: self.drag.cursor_pos,
                });
            }
        }
        self.drag.drag_active = false;
        self.drag.origin_fresh = false;
    }
}

/// Insertion index for a uniform-height virtualized list, from a cursor
/// position in the scrollable's content space (y = 0 at the top of the first
/// row). Snaps to the nearest row boundary, clamped into `[first, count]` —
/// correct even though only visible rows are laid out.
fn drop_index_from_cursor(cursor_y: f32, first: usize, count: usize) -> usize {
    let row_f = (cursor_y / crate::theme::ROW_HEIGHT).max(0.0);
    let idx = (row_f + 0.5).floor() as usize + first;
    idx.clamp(first, count)
}

/// Index of the row whose center is nearest to `cursor_y`, in the same space
/// as the row rectangles.
fn nearest_row_index(rows: &[iced::Rectangle], cursor_y: f32) -> Option<usize> {
    let mut best: Option<(f32, usize)> = None;
    for (i, row) in rows.iter().enumerate() {
        let d = (cursor_y - (row.y + row.height / 2.0)).abs();
        if best.is_none_or(|(bd, _)| d < bd) {
            best = Some((d, i));
        }
    }
    best.map(|(_, idx)| idx)
}

#[cfg(test)]
mod tests {
    use super::*;

    const ROW: f32 = crate::theme::ROW_HEIGHT;

    #[test]
    fn drop_index_snaps_to_nearest_boundary() {
        assert_eq!(drop_index_from_cursor(0.0, 1, 10), 1);
        assert_eq!(drop_index_from_cursor(ROW * 0.49, 1, 10), 1);
        assert_eq!(drop_index_from_cursor(ROW * 0.51, 1, 10), 2);
        assert_eq!(drop_index_from_cursor(ROW * 3.5 - 0.01, 1, 10), 4);
    }

    #[test]
    fn drop_index_clamps_to_range() {
        assert_eq!(drop_index_from_cursor(-100.0, 1, 5), 1);
        assert_eq!(drop_index_from_cursor(100_000.0, 1, 5), 5);
        assert_eq!(drop_index_from_cursor(ROW * 9.9, 1, 10), 10);
    }

    #[test]
    fn nearest_row_picks_closest_center() {
        let rows: Vec<iced::Rectangle> = (0..3)
            .map(|i| iced::Rectangle {
                x: 0.0,
                y: i as f32 * ROW,
                width: 100.0,
                height: ROW,
            })
            .collect();
        assert_eq!(nearest_row_index(&rows, ROW * 0.4), Some(0));
        assert_eq!(nearest_row_index(&rows, ROW * 1.6), Some(1));
        assert_eq!(nearest_row_index(&rows, ROW * 2.4), Some(2));
        assert_eq!(nearest_row_index(&rows, ROW), Some(0));
        assert_eq!(nearest_row_index(&[], 0.0), None);
    }
}
