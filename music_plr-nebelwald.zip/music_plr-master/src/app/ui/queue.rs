use iced::{
    alignment,
    widget::{rule, text, Button, Column, Container, Id, Row, Space},
    Element, Length, Padding,
};

use super::{
    shared_components::empty_state,
    styles::{bg_secondary, button_style_album, button_style_panel_item, fg_secondary},
    track_list::{track_row_layout, view_track_list, view_track_row, virtual_scrollable},
    Message, MusicPlayer,
};
use crate::{
    app::{
        interaction::TrackPos,
        pane::{is_main_pane, QUEUE_PANE_ID, RECENT_PANE_ID},
        ui::styles::{fg_accent, icon_tab},
        ViewKind,
    },
    icons,
    theme::{self, AppTheme},
    types::QueueTab,
};

pub const QUEUE_LIST_ID: Id = Id::new("queue_list");
pub const QUEUE_RECENT_LIST_ID: Id = Id::new("queue_recent_list");

pub(super) fn view_queue_panel(player: &MusicPlayer) -> Element<'_, Message, AppTheme> {
    let queue_width =
        (player.window_size.width * theme::QUEUE_WIDTH_RATIO).max(theme::QUEUE_MIN_WIDTH);

    let tab_bar = Container::new(view_queue_tabs(player))
        .width(Length::Fill)
        .style(bg_secondary());

    let track_list_search = match &player.track_list_search {
        Some(fs) if !is_main_pane(fs.pane) => {
            super::track_list_search::view_track_list_search(player, fs)
        }
        _ => Space::new().into(),
    };

    let view = match player.queue.queue_tab {
        QueueTab::Queue => view_queue_tab(player),
        QueueTab::RecentlyPlayed => view_recently_played_tab(player),
    };

    Container::new(Column::with_children([
        tab_bar.into(),
        track_list_search,
        view,
    ]))
    .width(queue_width)
    .style(bg_secondary())
    .into()
}

fn view_queue_tabs(player: &MusicPlayer) -> Element<'_, Message, AppTheme> {
    Row::with_children([
        queue_tab(player, player.strings.queue, QueueTab::Queue),
        queue_tab(
            player,
            player.strings.recently_played,
            QueueTab::RecentlyPlayed,
        ),
    ])
    .spacing(theme::SPACING_SM)
    .padding(theme::SPACING_SM)
    .into()
}

fn queue_tab<'a>(
    player: &'a MusicPlayer,
    label: &'a str,
    queue_tab: QueueTab,
) -> Element<'a, Message, AppTheme> {
    let active = player.queue.queue_tab == queue_tab;

    Button::new(
        Row::with_children([
            icons::icon(icons::MUSIC_ICON, theme::ICON_SIZE_SM)
                .style(icon_tab(active))
                .into(),
            text(label).into(),
        ])
        .spacing(theme::SPACING_SM)
        .padding([theme::SPACING_SM, theme::SPACING_MD])
        .align_y(alignment::Vertical::Center)
        .width(Length::Fill),
    )
    .padding(0)
    .style(button_style_panel_item(active))
    .on_press(Message::SwitchQueueTab(queue_tab))
    .into()
}

pub fn now_playing_source_label<'a>(
    kind: &'a ViewKind,
    tr: &'a crate::i18n::Strings,
) -> Option<&'a str> {
    match kind {
        ViewKind::Search(s) => (!s.query.is_empty()).then_some(s.query.as_str()),
        ViewKind::SongRadio(data) | ViewKind::ArtistRadio(data) => Some(&data.title),
        ViewKind::Artist(e) => Some(&e.name),
        ViewKind::Album(r) => Some(&r.name),
        ViewKind::PlaylistView(r) => Some(&r.name),
        ViewKind::Playlist(e) => Some(e.name.as_str()),
        ViewKind::Downloads => Some(tr.downloads),
        _ => None,
    }
}

pub(super) fn section_text(label: &str) -> Element<'_, Message, AppTheme> {
    text(label)
        .size(theme::TEXT_SIZE_XS)
        .style(fg_accent())
        .into()
}

fn view_queue_tab(player: &MusicPlayer) -> Element<'_, Message, AppTheme> {
    const NOW_PLAYING_PADDING: Padding = Padding {
        top: 0.0,
        right: theme::SPACING_MD,
        bottom: theme::SPACING_XS,
        left: theme::SPACING_MD,
    };
    let now_playing_header: Element<'_, Message, AppTheme> = match player
        .now_playing_from
        .as_ref()
        .and_then(|v| now_playing_source_label(&v.kind, player.strings))
    {
        Some(source) => Row::with_children([
            section_text(player.strings.now_playing_from),
            Button::new(text(source).size(theme::TEXT_SIZE_XS))
                .padding(0)
                .style(button_style_album())
                .on_press(Message::RevealNowPlaying)
                .into(),
        ])
        .spacing(theme::SPACING_XS)
        .padding(NOW_PLAYING_PADDING)
        .align_y(alignment::Vertical::Center)
        .into(),
        None => Container::new(section_text(player.strings.now_playing))
            .padding(NOW_PLAYING_PADDING)
            .into(),
    };

    let now_playing_row: Element<'_, Message, AppTheme> =
        if let Some(track) = player.queue.current() {
            Container::new(track_row_layout(
                Space::new().into(),
                track,
                player,
                TrackPos::new(0, QUEUE_PANE_ID),
                false,
            ))
            .height(theme::ROW_HEIGHT)
            .into()
        } else {
            Container::new(
                text(player.strings.no_track_playing)
                    .size(theme::TEXT_SIZE_SM)
                    .style(fg_secondary()),
            )
            .padding(theme::SPACING_MD)
            .into()
        };

    let up_next_header = Container::new(section_text(player.strings.up_next))
        .padding([theme::SPACING_SM, theme::SPACING_MD]);

    let offset = 1;
    let upcoming = if offset <= player.queue.tracks.len() {
        &player.queue.tracks[offset..]
    } else {
        &[]
    };

    let up_next: Element<'_, Message, AppTheme> = if upcoming.is_empty() {
        Container::new(
            text(player.strings.no_more_tracks_in_queue)
                .size(theme::TEXT_SIZE_SM)
                .style(fg_secondary()),
        )
        .padding(theme::SPACING_MD)
        .into()
    } else {
        view_track_list(upcoming, player, QUEUE_PANE_ID, offset)
    };

    Column::with_children([
        now_playing_header,
        now_playing_row,
        rule::horizontal(1)
            .style(move |theme: &AppTheme| rule::Style {
                color: theme.palette.fg_muted,
                radius: iced::border::Radius::new(0),
                fill_mode: rule::FillMode::Padded(theme::SPACING_MD as u16),
                snap: true,
            })
            .into(),
        up_next_header.into(),
        up_next,
    ])
    .width(Length::Fill)
    .height(Length::Fill)
    .into()
}

fn view_recently_played_tab(player: &MusicPlayer) -> Element<'_, Message, AppTheme> {
    let tracks = &player.queue.recently_played;

    if tracks.is_empty() {
        return empty_state(player.strings.no_recently_played_tracks);
    }

    virtual_scrollable(tracks.len(), RECENT_PANE_ID, player, |i| {
        view_track_row(&tracks[i], TrackPos::new(i, RECENT_PANE_ID), player, false)
    })
}
