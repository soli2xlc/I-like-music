use iced::{
    advanced::{
        layout, mouse, overlay, renderer,
        widget::{tree, Operation, Tree},
        Clipboard, Layout, Shell, Widget,
    },
    Element, Event, Length, Rectangle, Size, Vector,
};

use super::Message;

/// Reports right-clicks with the cursor position. `MouseArea::on_right_press`
/// carries no position and the global cursor subscription runs only while
/// dragging, so a wrapper that observes the press in place is the only quiet
/// way to anchor the context menu at the cursor. The point travels with the
/// event instead of the shared cursor channel, so a right-click can never be
/// mistaken for drag movement.
///
/// The point is in the list's content space: a scrollable hands its content a
/// cursor shifted by the scroll offset. The handler converts it to window
/// coordinates with the list's captured scroll offset before anchoring.
///
/// Transparent pass-through like `Container`: tag/state/children/diff are the
/// content's own, so widget state and tree shape are unchanged. Right presses
/// are observed before delegating and never captured, so hover, press, focus,
/// and scroll behavior are unchanged.
///
/// `P` is whatever the right-click identifies — a track row's `TrackPos`, or a
/// card's identity — and `make` turns it plus the cursor point into the
/// message that opens that kind of menu.
pub struct RightClickArea<'a, P> {
    content: Element<'a, Message, crate::theme::AppTheme, iced::Renderer>,
    payload: P,
    make: fn(P, iced::Point) -> Message,
}

impl<'a, P: Clone> RightClickArea<'a, P> {
    pub fn new(
        content: impl Into<Element<'a, Message, crate::theme::AppTheme, iced::Renderer>>,
        payload: P,
        make: fn(P, iced::Point) -> Message,
    ) -> Self {
        Self {
            content: content.into(),
            payload,
            make,
        }
    }
}

impl<P: Clone> Widget<Message, crate::theme::AppTheme, iced::Renderer> for RightClickArea<'_, P> {
    fn tag(&self) -> tree::Tag {
        self.content.as_widget().tag()
    }

    fn state(&self) -> tree::State {
        self.content.as_widget().state()
    }

    fn children(&self) -> Vec<Tree> {
        self.content.as_widget().children()
    }

    fn diff(&self, tree: &mut Tree) {
        self.content.as_widget().diff(tree);
    }

    fn size(&self) -> Size<Length> {
        self.content.as_widget().size()
    }

    fn layout(
        &mut self,
        tree: &mut Tree,
        renderer: &iced::Renderer,
        limits: &layout::Limits,
    ) -> layout::Node {
        self.content.as_widget_mut().layout(tree, renderer, limits)
    }

    fn operate(
        &mut self,
        tree: &mut Tree,
        layout: Layout<'_>,
        renderer: &iced::Renderer,
        operation: &mut dyn Operation,
    ) {
        self.content
            .as_widget_mut()
            .operate(tree, layout, renderer, operation);
    }

    fn update(
        &mut self,
        tree: &mut Tree,
        event: &Event,
        layout: Layout<'_>,
        cursor: mouse::Cursor,
        renderer: &iced::Renderer,
        clipboard: &mut dyn Clipboard,
        shell: &mut Shell<'_, Message>,
        viewport: &Rectangle,
    ) {
        if matches!(
            event,
            Event::Mouse(mouse::Event::ButtonPressed(mouse::Button::Right))
        ) {
            if let Some(point) = cursor.position_over(layout.bounds()) {
                shell.publish((self.make)(self.payload.clone(), point));
            }
        }

        self.content.as_widget_mut().update(
            tree, event, layout, cursor, renderer, clipboard, shell, viewport,
        );
    }

    fn mouse_interaction(
        &self,
        tree: &Tree,
        layout: Layout<'_>,
        cursor: mouse::Cursor,
        viewport: &Rectangle,
        renderer: &iced::Renderer,
    ) -> mouse::Interaction {
        self.content
            .as_widget()
            .mouse_interaction(tree, layout, cursor, viewport, renderer)
    }

    fn draw(
        &self,
        tree: &Tree,
        renderer: &mut iced::Renderer,
        theme: &crate::theme::AppTheme,
        style: &renderer::Style,
        layout: Layout<'_>,
        cursor: mouse::Cursor,
        viewport: &Rectangle,
    ) {
        self.content
            .as_widget()
            .draw(tree, renderer, theme, style, layout, cursor, viewport);
    }

    fn overlay<'b>(
        &'b mut self,
        tree: &'b mut Tree,
        layout: Layout<'b>,
        renderer: &iced::Renderer,
        viewport: &Rectangle,
        translation: Vector,
    ) -> Option<overlay::Element<'b, Message, crate::theme::AppTheme, iced::Renderer>> {
        self.content
            .as_widget_mut()
            .overlay(tree, layout, renderer, viewport, translation)
    }
}

impl<'a, P: Clone + 'a> From<RightClickArea<'a, P>>
    for Element<'a, Message, crate::theme::AppTheme, iced::Renderer>
{
    fn from(area: RightClickArea<'a, P>) -> Self {
        Element::new(area)
    }
}
